// 把获取html内容的声明放在前面，避免出错
let index = document.querySelector('.index')
let concern = document.querySelector('.concern')
let release = document.querySelector('.post')
let peripheral = document.querySelector('.peripheral')
let mine = document.querySelector('.mine')
let login = document.querySelector('.login')
let footer = document.querySelector('footer')
let subheadings = document.querySelector('.subheadings')
let pages = document.querySelectorAll('.page')
let eye = document.querySelector('.eye')
let password = document.querySelector('#password')
let flag = 0
    // 用一个对象存放首页文章
let indexArticle = {}
let literatureArticle = {}
let drawingArticle = {}
let photographArticle = {}
let filmArticle = {}
let entertainmentArticle = {}
    //这里选出要显示的页面
let container0 = document.querySelector('.box')
let container1 = document.querySelectorAll('.box')[1]
let container2 = document.querySelectorAll('.box')[2]
let container3 = document.querySelectorAll('.box')[3]
let container4 = document.querySelectorAll('.box')[4]
let container5 = document.querySelectorAll('.box')[5]
    // console.log(container1);
let itemNum0
let itemNum0Arr = []
let itemNum1
let itemNum1Arr = []
let itemNum2
let itemNum2Arr = []
let itemNum3
let itemNum3Arr = []
let itemNum4
let itemNum4Arr = []
let itemNum5
let itemNum5Arr = []
    // 封装xhr
    // 封装post请求
function post(url, data, success) {
    let xhr = new XMLHttpRequest
    xhr.addEventListener('readystatechange', function() {
        if (xhr.readyState == 4 && xhr.status == 200)
        // console.log(xhr.responseText);
            success(xhr.responseText)
    })

    xhr.open('post', url)
        //检测有没有token，如果有的话把token放在请求头里面
    if (data) {
        xhr.setRequestHeader('Content-type', 'aplication/x-www-form-urlencoded')
    }
    if (localStorage.getItem('token')) {
        xhr.setRequestHeader('Authorization', localStorage.getItem('token'))
    }
    xhr.send(data)
}

//封装get请求
function get(url, data, success) {

    let xhr = new XMLHttpRequest()
    if (data) {
        url += '?'
        url += data
    }
    xhr.open('get', url)
        //检测有没有token，如果有的话把token放在请求头里面

    if (localStorage.getItem('token')) {
        xhr.setRequestHeader('Authorization', localStorage.getItem('token'))
    }
    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4 && xhr.status == 200) {
            success(xhr.responseText)
        }
    }
    xhr.send()
}

// 由于formdata表单不需要解码，故额外再设置一个没有urlencoded的函数,顺便在返回内容的基础上把其他的跳转功能也写了
function formData_post(url, data, success) {
    let xhr = new XMLHttpRequest
    xhr.addEventListener('readystatechange', function() {
        if (xhr.readyState == 4 && xhr.status == 200) {
            success(xhr.responseText)
        }
    })
    xhr.open('post', url)
    if (localStorage.getItem('token')) {
        xhr.setRequestHeader('Authorization', localStorage.getItem('token'))
    }
    xhr.send(data)
}

//下面的要使用正则表达式，但是正则表达式内好像不能接一大段函数，因此这里把函数分离出来
function getPostpage() {
    alert('发布成功')
    published.style.display = 'none'
    addTagPage.style.display = 'none'
    tagBox.style.display = 'none'
    toPostArticlePage.style.display = 'block'
    footer.style.display = 'flex'
}

function getLoginPage() {
    mine.style.display = 'none'
    login.style.display = 'block'
}
// 登录的回调函数
getLogin = function() {
    getLoginPage()
    let button = document.querySelector('.upload')
    button.addEventListener('click', function() {
        let account = document.querySelector('#account').value
        let password = document.querySelector('#password').value

        post("http://175.178.4.54:3007/user/login", `username=${account}&password=${password}`, function(data) {
            let re = JSON.parse(data)
            console.log(re);
            if (re.status == 200) {
                localStorage.setItem('token', re.data.token)
                localStorage.setItem('id', re.data.id)
                alert('登陆成功')
                getIndex()
                getContent()
            } else {
                alert('账号或密码错误')
                return false
            }
        })
    })
}


// 让首页显示
function getIndex() {
    login.style.display = 'none'
    footer.style.display = 'flex'
    index.style.display = 'block'
    subheadings.firstChild.className = 'checked'
    pages[0].style.display = 'block'
}

// 获取首页文章   后面几个的内容都好相似，后面有空的话可以直接用一个函数来替换掉这里的一大堆内容
function getIndexArticle() {
    let p = new Promise((resolve, reject) => {
        //这里才发现要做分页效果，但是来不及了  应该是小问题吧，我现在搞明白观察者模式了，其实感觉不分页也还行
        get('http://175.178.4.54:3007/article/getArticle', 'type=推荐&page=1&size=10000', function(data) {
            if (localStorage.getItem('indexArticleNumber')) {
                localStorage.removeItem('indexArticleNumber')
                localStorage.setItem('indexArticleNumber', JSON.parse(data).data.articleList.length)
            } else {
                localStorage.setItem('indexArticleNumber', JSON.parse(data).data.articleList.length)
            }
            indexArticle = JSON.parse(data).data.articleList
            console.log(indexArticle);
            resolve(indexArticle)
        })
    })
    p.then(
        // 字符串拼接创建多个盒子
        (indexArticle) => {
            let str = ''
            for (let i = 0; i < indexArticle.length; i++) {
                str += `<div class="item"><img data-src=${indexArticle[i].avatar}>
    <div class="text"><span data-text=${indexArticle[i].title}></span><span class="more">&#xe600;</span></div>
    <div class="tag"><div data-text=${indexArticle[i].label[0]}></div></div>
    <div class="bottomRow">
    <div class="headPortrait"><img  data-src=${indexArticle[i].cover}></div>
    <div class="nickname" data-text=${indexArticle[i].username}></div>
    <div class="upvote"> <div class="heart">&#xe653;</div> <div class="number" data-number=${indexArticle[i].fanNum}></div>
    </div></div></div>`
            }
            container0.innerHTML = str
            itemNum0 = container0.children
            itemNum0Arr = [...itemNum0]
                // 观察者模式：当看见元素的时候，让他加载：把前面预存在data-的数据给拿出来
            const callback = entries => {
                    for (let i = 0; i < entries.length; i++) {
                        if (entries[i].isIntersecting) {
                            let item = entries[i].target
                            let data_src0 = item.children[0].getAttribute('data-src')
                            item.children[0].setAttribute('src', data_src0)
                            let data_text0 = item.children[1].firstChild.getAttribute('data-text')
                            item.children[1].firstChild.innerHTML = data_text0
                            let data_text1 = item.children[2].firstElementChild.getAttribute('data-text')
                            item.children[2].firstElementChild.innerHTML = '#' + data_text1
                            let data_src1 = item.children[3].firstElementChild.firstElementChild.getAttribute('data-src')
                            item.children[3].firstElementChild.firstElementChild.setAttribute('src', data_src1)
                            let data_text2 = item.children[3].children[1].getAttribute('data-text')
                            item.children[3].children[1].innerHTML = data_text2
                            let data_number = item.children[3].children[2].children[1].getAttribute('data-number')
                            item.children[3].children[2].children[1].innerHTML = data_number
                            observer.unobserve(item)
                            console.log('触发');
                        }
                    }
                    // 这个本来是同步的，加载图片是异步的，那么只需让排序也放进堆内执行，就可以实现瀑布流，于是给一个很短的定时器来实现
                    setTimeout(function() {
                        let oItem = container0.children
                        let clientwidth = document.documentElement.clientWidth
                        let itemWidth = oItem[0].offsetWidth
                        let num = Math.floor(clientwidth / itemWidth)
                        container0.style.width = num * itemWidth + 1 + 'px'
                        let hrr = []
                        for (let i = 0; i < container0.children.length; i++) {
                            if (i < num) {
                                hrr.push(container0.children[i].offsetHeight)
                                console.log(hrr);
                            } else {
                                let minHeight = Math.min(...hrr)
                                let index = fInArray(minHeight, hrr)
                                container0.children[i].style.position = 'absolute'
                                container0.children[i].style.top = minHeight + 'px'
                                container0.children[i].style.left = index * itemWidth + 'px'
                                hrr[index] += container0.children[i].offsetHeight
                            }
                        }
                        //这里设定的时间对瀑布流排序有着重大影响，待寻找原因  ...现在知道了，因为没加载完，看到盒子与加载之间有时间差，对首页刚看见的盒子影响最明显
                    }, 100)
                }
                // 当看见的时候调用回调函数
            const observer = new IntersectionObserver(callback)
            itemNum0Arr.forEach(item => {
                observer.observe(item)
            })

            function fInArray(min, hrr) {
                for (let i = 0; i < hrr.length; i++) {
                    if (hrr[i] == min) {
                        return i
                    }
                }
            }
            //点击盒子让详细内容加载
            for (let i = 0; i < container0.children.length; i++) {
                //在获取文章详细信息之前，先检测一下文章有没有被我喜欢
                container0.children[i].addEventListener('click', function() {
                    // linkState初始值是0，如果发送取消喜欢请求后成功取消的话，那么说明已经喜欢过了，让linkState等于1，并发送一次喜欢请求恢复原样
                    //其实可以在这里把喜欢，收藏，关注请求一起发，然后用promise.all一起接收的，可以简化一下逻辑
                    let likingState = 0
                    let likingStateOfCollect = 0
                    let likingStateOfFocus = 0
                    let p0 = new Promise((resolve, reject) => {
                            console.log(indexArticle[i])
                            post('http://175.178.4.54:3007/like/cancelLikeArticle', `article_id=${indexArticle[i].articleId}`, function(data) {
                                console.log(data);
                                console.log(JSON.parse(data));
                                if (JSON.parse(data).message != '您还没有喜欢过该文章') {
                                    post('http://175.178.4.54:3007/like/likeArticle', `article_id=${indexArticle[i].articleId}`, function(data) {
                                        console.log(data);
                                    })
                                    likingState = 1
                                } else {
                                    likingState = 0
                                }
                                resolve(likingState)
                            })
                        })
                        // 同理，先发个取消收藏的请求 已收藏，则likingStateOfCollect，否则 ，likingStateOfCollect=0
                    let p1 = new Promise((resolve, reject) => {
                            post('http://175.178.4.54:3007/star/cancelStarArticles', `article_id=${indexArticle[i].articleId}`, function(data) {
                                console.log(JSON.parse(data));
                                if (JSON.parse(data).message != '您还没有收藏过该文章') {
                                    post('http://175.178.4.54:3007/star/starArticles', `article_id=${indexArticle[i].articleId}`, function(data) {
                                        console.log(data);
                                    })
                                    likingStateOfCollect = 1
                                } else {
                                    likingStateOfCollect = 0
                                }
                                resolve(likingStateOfCollect)
                            })
                        })
                        //接口有问题 确实有问题，只要把这里的功能放进去就报错 empty response
                        // let p2 = new Promise((resolve, reject) => {
                        //         post('http://175.178.4.54:3007/follow/followUser', `userId=${indexArticle[i].authorId}`, function(data) {
                        //             console.log(data);
                        //             if (JSON.parse(data).message != '您还没有关注过该用户') {
                        //                 post('http://175.178.4.54:3007/follow/unfollow', `userId=${indexArticle[i].authorId}`, function(data) {
                        //                     console.log(data);
                        //                 })
                        //                 likingStateOfFocus = 1
                        //             } else {
                        //                 likingStateOfFocus = 0
                        //             }
                        //             resolve(likingStateOfFocus)
                        //         })
                        //     })
                        // 关注接口有问题，这里放个备用的等好了再替换
                    let pAll = Promise.all([p0, p1])
                        // let pAll = Promise.all([p0, p1, p2])
                    pAll.then(() => {
                        [likingState, likingStateOfCollect] = [p0, p1]
                        // [likingState, likingStateOfCollect, likingStateOfFocus] = [p0, p1, p2]
                        get('http://175.178.4.54:3007/article/getDetails', `articleId=${indexArticle[i].articleId}`, function(data) {
                            console.log(JSON.parse(data));
                            let details_title = document.querySelector('#details_title')
                            console.log(details_title);
                            //将除了底下的评论部分的内容放进页面中
                            let str = `
            <div id="othersInformation">
            <div id='othersInformationTitle'>
            <div id="othersGoBack">&#xe8ef;</div>
                <div id="othersHeadPortrait"><img src=${JSON.parse(data).data.avatar} ></div>
                <div id="othersName_time">
                    <div id="othersName">${JSON.parse(data).data.authorName}</div>
                    <div id="othersTime">${JSON.parse(data).data.time}</div>
                </div>
                <div id="othersFocus">关注</div>
                </div>
                <div id='othersContentBody'>
                <div id="othersImg"><img src=${JSON.parse(data).data.img[0]}  ></div>
                <div id="othersContent">${JSON.parse(data).data.content}</div>
                <div id="othersTag"></div>
                <div id="others_love_comment_collect"><span>&#xe653;</span><span id="commentIcon">&#xe8b4;</span><span id="collectIcon">&#xe8ba;</span></div>
                <div id="fanNum_commentNum">
                    <i id="hotNumberText"><span>热度</span> <span>${JSON.parse(data).data.fanNum}</span></i>
                    <i id="commentNumberText"><span>评论</span> <span>${JSON.parse(data).data.reviewNum}</span></i>
                </div>
                </div>
                <div id="comment">
        <div id="hotComment">热门评论</div>
        <div id="commentDetails"></div>
        <div id="reviewBottom"><input type="text" placeholder="我要发评论">
            <div id='reviewBottomUpvote'>
                <div>&#xe653;</div>
                <div>${JSON.parse(data).data.fanNum}</div>
            </div>
            <div id='reviewBottomReview'>
                <div>&#xe8b4;</div>
                <div>${JSON.parse(data).data.reviewNum}</div>
            </div>
        </div>
        <div id='secondaryComments'><span id='putAway'>&#xe601;</span></div>
        <div id="checkMoreReview">查看更多评论</div>
    </div>
            </div>`
                            details_title.innerHTML = str
                                //文章中的各种数据
                            let hotNumberText = document.querySelector('#hotNumberText')
                            let img = document.querySelector('#othersImg').children[0]
                                //当图片加载不出来的时候隐藏
                            img.addEventListener('error', function() {
                                this.style.display = 'none'
                            })
                            let othersTag = document.querySelector('#othersTag')
                                // 给文章添加标签
                            for (let i = 0; i < JSON.parse(data).data.label.length; i++) {
                                othersTag.innerHTML += `<i>${JSON.parse(data).data.label[i]}</i>`
                            }
                            // 根据 LS,LSC,LSF的值来确定文章中的喜欢，收藏，关注图标的样式
                            let others_love_comment_collect = document.querySelector('#others_love_comment_collect')
                            if (likingState == 1) {
                                others_love_comment_collect.children[0].innerHTML = '&#xe642;'
                            } else {
                                others_love_comment_collect.children[0].innerHTML = '&#xe653;'
                            }
                            if (likingStateOfCollect == 1) {
                                others_love_comment_collect.children[2].innerHTML = '&#xe8c6;'
                            } else {
                                others_love_comment_collect.children[2].innerHTML = '&#xe8ba;'
                            }
                            if (likingStateOfFocus == 1) {
                                let othersFocus = document.querySelector('#othersFocus')
                                othersFocus.innerHTML = '已关注'
                                othersFocus.className = 'othersFocus_focused'
                            } else {
                                othersFocus.innerHTML = '关注'
                                othersFocus.className = ''
                            }

                            // 加载具体的评论
                            let p1 = new Promise((resolve, reject) => {
                                get('http://175.178.4.54:3007/review/getReviewsByArt', `articleId=${indexArticle[i].articleId}&page=1&size=20`, function(data) {
                                    let reviewReturn = data
                                    console.log(JSON.parse(reviewReturn));
                                    resolve(reviewReturn)
                                })
                            })
                            p1.then((reviewReturn) => {
                                    // 在热门评论处添加评论
                                    let commentDetails = document.querySelector('#commentDetails')
                                    let checkMoreReview = document.querySelector('#checkMoreReview')
                                        //如果评论数小于等于2，则隐藏展示更多评论的功能
                                        //此处移植过去后可先判断没有评论的情况，顺便把展开更多评论也改一下
                                    if (JSON.parse(reviewReturn).list.length <= 2 && JSON.parse(reviewReturn).list.length != 0) {
                                        let str1 = ''
                                        for (let i = 0; i < JSON.parse(reviewReturn).list.length; i++) {
                                            str1 += `<div class="commentBox">
    <div class="othersCommentHeadportrait"><img src=${JSON.parse(reviewReturn).list[i].userInfo.avatar}  ></div>
    <div class="othersCommentNickname">${JSON.parse(reviewReturn).list[i].userInfo.userName}</div>
    <div class="othersCommentContent">${JSON.parse(reviewReturn).list[i].content}</div>
    <div class="othersCommentTime">${JSON.parse(reviewReturn).list[i].time}</div>
    <div class="othersMoreComment">-查看更多<span>${JSON.parse(reviewReturn).list[i].childrenReviews.length}</span>条回复-</div>
    <div class="othersCommentUpvote">
    <div>&#xe653;</div>
    <div>${JSON.parse(reviewReturn).list[i].goodNum}</div>
    </div>
    </div>
    </div><div id='layer'></div>`
                                        }
                                        commentDetails.innerHTML = str1
                                        checkMoreReview.style.display = 'none'
                                            //如果评论的子评论数=0，则隐藏展示子评论的功能
                                        for (let i = 0; i < JSON.parse(reviewReturn).list.length; i++) {
                                            if (JSON.parse(reviewReturn).list[i].childrenReviews.length == 0) {
                                                let othersMoreComment = document.querySelectorAll('.othersMoreComment')
                                                othersMoreComment[i].style.display = 'none'
                                            }
                                        }
                                    } else if (JSON.parse(reviewReturn).list.length == 0) {
                                        checkMoreReview.style.display = 'none'
                                    } else {
                                        // 当评论数大于2的情况，加载两项评论，如果二级评论数为0的话，隐藏展开评论
                                        //先加载两项，等点击加载更多以后再显示全部
                                        let str1 = ''
                                        for (let i = 0; i < 2; i++) {
                                            str1 += `<div class="commentBox">
    <div class="othersCommentHeadportrait"><img src=${JSON.parse(reviewReturn).list[i].userInfo.avatar}  ></div>
    <div class="othersCommentNickname">${JSON.parse(reviewReturn).list[i].userInfo.userName}</div>
    <div class="othersCommentContent">${JSON.parse(reviewReturn).list[i].content}</div>
    <div class="othersCommentTime">${JSON.parse(reviewReturn).list[i].time}</div>
    <div class="othersMoreComment">-查看更多<span>${JSON.parse(reviewReturn).list[i].childrenReviews.length}</span>条回复-</div>
    <div class="othersCommentUpvote">
    <div>&#xe653;</div>
    <div>${JSON.parse(reviewReturn).list[i].goodNum}</div>
    </div>
    </div>
    </div><div id='layer'></div>`
                                        }
                                        commentDetails.innerHTML = str1
                                            //如果评论的子评论数=0，则隐藏展示子评论的功能
                                        for (let i = 0; i < 2; i++) {
                                            if (JSON.parse(reviewReturn).list[i].childrenReviews.length == 0) {
                                                let othersMoreComment = document.querySelectorAll('.othersMoreComment')
                                                othersMoreComment[i].style.display = 'none'
                                            }
                                        }
                                        //当加载更多评论被点击以后，加载更多评论，当二级评论数为0的话，隐藏展开评论
                                        checkMoreReview.addEventListener('click', function() {
                                            let str1 = ``
                                            for (let i = 0; i < JSON.parse(reviewReturn).list.length; i++) {
                                                str1 += `<div class="commentBox">
        <div class="othersCommentHeadportrait"><img src=${JSON.parse(reviewReturn).list[i].userInfo.avatar}  ></div>
        <div class="othersCommentNickname">${JSON.parse(reviewReturn).list[i].userInfo.userName}</div>
        <div class="othersCommentContent">${JSON.parse(reviewReturn).list[i].content}</div>
        <div class="othersCommentTime">${JSON.parse(reviewReturn).list[i].time}</div>
        <div class="othersMoreComment">-查看更多<span>${JSON.parse(reviewReturn).list[i].childrenReviews.length}</span>条回复-</div>
        <div class="othersCommentUpvote">
        <div>&#xe653;</div>
        <div>${JSON.parse(reviewReturn).list[i].goodNum}</div>
        </div></div>
        </div><div id='layer'></div>`
                                            }
                                            commentDetails.innerHTML = str1
                                            checkMoreReview.style.display = 'none'
                                                //如果评论的子评论数=0，则隐藏展示子评论的功能
                                            for (let i = 0; i < JSON.parse(reviewReturn).list.length; i++) {
                                                if (JSON.parse(reviewReturn).list[i].childrenReviews.length == 0) {
                                                    let othersMoreComment = document.querySelectorAll('.othersMoreComment')
                                                    othersMoreComment[i].style.display = 'none'
                                                }
                                            }
                                        })
                                    }
                                    // 让发评论旁边的小爱心图标与点赞数与上方的一致
                                    let reviewBottomUpvote = document.querySelector('#reviewBottomUpvote')
                                    reviewBottomUpvote.children[0].innerHTML = others_love_comment_collect.children[0].innerHTML
                                    reviewBottomUpvote.children[1].innerHTML = hotNumberText.children[1].innerHTML
                                        // 当上方的爱心被点击时,如果点赞的值为1，说明点赞了，那么被点击的时候取消点赞
                                    others_love_comment_collect.children[0].addEventListener('click', function() {
                                            if (likingState == 1) {
                                                //发取消点赞请求
                                                post('http://175.178.4.54:3007/like/cancelLikeArticle', `article_id=${indexArticle[i].articleId}`, function(data) {
                                                    console.log(data);
                                                    others_love_comment_collect.children[0].innerHTML = '&#xe653;'
                                                    likingState = 0
                                                    let hotNumberText = document.querySelector('#hotNumberText')
                                                    hotNumberText.children[1].innerHTML = parseInt(hotNumberText.children[1].innerHTML) - 1
                                                    reviewBottomUpvote.children[0].innerHTML = others_love_comment_collect.children[0].innerHTML
                                                    reviewBottomUpvote.children[1].innerHTML = hotNumberText.children[1].innerHTML
                                                })
                                            } else {
                                                //发点赞请求
                                                post('http://175.178.4.54:3007/like/likeArticle', `article_id=${indexArticle[i].articleId}`, function(data) {
                                                    console.log(data);
                                                    others_love_comment_collect.children[0].innerHTML = '&#xe642;'
                                                    likingState = 1
                                                    console.log(hotNumberText);
                                                    hotNumberText.children[1].innerHTML = parseInt(hotNumberText.children[1].innerHTML) + 1
                                                    reviewBottomUpvote.children[0].innerHTML = others_love_comment_collect.children[0].innerHTML
                                                    reviewBottomUpvote.children[1].innerHTML = hotNumberText.children[1].innerHTML
                                                })
                                            }
                                        })
                                        //做下方的发评论
                                    let postReview = reviewBottom.querySelector('input')
                                        //当敲下键盘时，发送评论
                                    postReview.addEventListener('keydown', function(event) {
                                            if (event.keyCode == 13) {
                                                post('http://175.178.4.54:3007/review/submitReview', `content=${postReview.value}&articleId=${indexArticle[i].articleId}`, function() {
                                                    console.log(JSON.parse(data));
                                                    if (JSON.parse(data).status == 200) {
                                                        alert('发布成功')
                                                        postReview.value = ''
                                                    } else {
                                                        alert('未发布成功，请重试')
                                                    }
                                                })
                                                get('http://175.178.4.54:3007/review/getReviewsByArt', `articleId=${indexArticle[i].articleId}&page=1&size=2`, function() {
                                                    console.log(JSON.parse(data));
                                                })
                                            }
                                        })
                                        //仿照爱心点击做一个收藏点击事件
                                    others_love_comment_collect.children[2].addEventListener('click', function() {
                                            if (likingStateOfCollect == 1) {
                                                post('http://175.178.4.54:3007/star/cancelStarArticles', `article_id=${indexArticle[i].articleId}`, function(data) {
                                                    console.log(data);
                                                    others_love_comment_collect.children[2].innerHTML = '&#xe8ba;'
                                                    likingStateOfCollect = 0
                                                })

                                            } else {
                                                post('http://175.178.4.54:3007/star/starArticles', `article_id=${indexArticle[i].articleId}`, function(data) {
                                                    console.log(data);
                                                    others_love_comment_collect.children[2].innerHTML = '&#xe8c6;'
                                                    likingStateOfCollect = 1
                                                })
                                            }
                                        })
                                        //关注按钮被点击  接口报错，待处理
                                        // othersFocus.addEventListener('click', function() {
                                        //         if (likingStateOfFocus == 1) {
                                        //             post('http://175.178.4.54:3007/follow/unfollow?', `userId=userId=${indexArticle[i].authorId}`, function(data) {
                                        //                 console.log(data);
                                        //                 othersFocus.innerHTML = '关注'
                                        //                 othersFocus.className = ''
                                        //             })

                                    //         } else {
                                    //             post('http://175.178.4.54:3007/follow/followUser', `userId=${indexArticle[i].authorId}`, function(data) {
                                    //                 console.log(data);
                                    //                 othersFocus.innerHTML = '已关注'
                                    //                 othersFocus.className = 'othersFocus_focused'
                                    //             })
                                    //         }
                                    //     })


                                    //本来是复制上方的爱心点击代码，想到下面的爱心被点击与上方的爱心点击等效，于是将下一个爱心的点击事件与上方爱心点击事件连接起来
                                    reviewBottomUpvote.addEventListener('click', function() {
                                            others_love_comment_collect.children[0].click()
                                        })
                                        //展开更多评论
                                    let othersMoreComment = document.querySelectorAll('.othersMoreComment')
                                    for (let i = 0; i < document.querySelectorAll('.commentBox').length; i++) {
                                        othersMoreComment[i].addEventListener('click', function() {
                                            othersMoreComment[i].style.display = 'none'
                                            let secondaryComments = document.querySelector('#secondaryComments')
                                            let othersInformationTitle = document.querySelector('#othersInformationTitle')
                                            let othersContentBody = document.querySelector('#othersContentBody')
                                            secondaryComments.style.display = 'block'
                                                //写二级评论
                                            let str2 = ''
                                            let layer = document.querySelector('#layer')
                                            for (let j = 0; j < JSON.parse(reviewReturn).list[i].childrenReviews.length; j++) {
                                                let p2 = new Promise((resolve, reject) => {
                                                    get('http://175.178.4.54:3007/userInfo/getUserInfo', `id=${JSON.parse(reviewReturn).list[i].childrenReviews[j].authorId}`, function(data) {
                                                        console.log(JSON.parse(data));
                                                        let userMessage = JSON.parse(data)
                                                        resolve(userMessage)
                                                    })
                                                })
                                                p2.then((userMessage) => {
                                                    for (let k = 0; k < JSON.parse(reviewReturn).list[i].childrenReviews.length; k++) {
                                                        str2 += `<div class="commentBox">
                                                            <div class="othersSecondaryCommentHeadportrait"><img src=${userMessage.data.avatar}  ></div>
                                                            <div class="othersCommentNickname">${userMessage.data.username}</div>
                                                            <div class="othersCommentContent">${JSON.parse(reviewReturn).list[i].childrenReviews[j].content}</div>
                                                            <div class="othersCommentTime">${JSON.parse(reviewReturn).list[i].childrenReviews[j].time}</div>
                                                            <div class="othersCommentUpvote">
                                                            <div>&#xe653;</div>
                                                            <div>${JSON.parse(reviewReturn).list[i].childrenReviews[j].goodNum}</div>
                                                            </div></div>
                                                            
                                                            `
                                                    }
                                                    secondaryComments.innerHTML += str2
                                                    layer.style.display = 'block'
                                                    let putAway = document.querySelector('#putAway')
                                                    putAway.addEventListener('click', function() {
                                                        secondaryComments.style.display = 'none'
                                                        layer.style.display = 'none'
                                                        othersMoreComment[i].style.display = 'block'
                                                    })
                                                }, () => {})

                                            }

                                        })
                                    }
                                }, () => {})
                                //点进文章页以后，当前显示的页面消失，替换成文章页
                            details_title.style.display = 'block'
                            index.style.display = 'none'
                            footer.style.display = 'none'
                            let othersGoBack = document.querySelector('#othersGoBack')
                            othersGoBack.addEventListener('click', function() {
                                details_title.style.display = 'none'
                                index.style.display = 'block'
                                footer.style.display = 'flex'
                            })
                        })


                    }, () => {})

                })
            }
        },
        () => {}
    )
}

getIndexArticle()

//获取文学文章 
function getLiteratureArticle() {
    // 获取首页文章   后面几个的内容都好相似，后面有空的话可以直接用一个函数来替换掉这里的一大堆内容
    let p = new Promise((resolve, reject) => {
        //这里才发现要做分页效果，但是来不及了  应该是小问题吧，我现在搞明白观察者模式了，其实感觉不分页也还行
        get('http://175.178.4.54:3007/article/getArticle', 'type=文学&page=1&size=10', function(data) {
            if (localStorage.getItem('literatureArticleNumber')) {
                localStorage.removeItem('literatureArticleNumber')
                localStorage.setItem('literatureArticleNumber', JSON.parse(data).data.articleList.length)
            } else {
                localStorage.setItem('literatureArticleNumber', JSON.parse(data).data.articleList.length)
            }
            literatureArticle = JSON.parse(data).data.articleList
            console.log(literatureArticle);
            resolve(literatureArticle)
        })

    })
    p.then(
        // 字符串拼接创建多个盒子
        (literatureArticle) => {
            let str = ''
            for (let i = 0; i < literatureArticle.length; i++) {
                str += `<div class="item"><img data-src=${literatureArticle[i].avatar}>
    <div class="text"><span data-text=${literatureArticle[i].title}></span><span class="more">&#xe600;</span></div>
    <div class="tag"><div data-text=${literatureArticle[i].label[0]}></div></div>
    <div class="bottomRow">
    <div class="headPortrait"><img  data-src=${literatureArticle[i].cover}></div>
    <div class="nickname" data-text=${literatureArticle[i].username}></div>
    <div class="upvote"> <div class="heart">&#xe653;</div> <div class="number" data-number=${literatureArticle[i].fanNum}></div>
    </div>
    </div>
    </div>`
            }
            container1.innerHTML = str
            itemNum1 = container1.children
            itemNum1Arr = [...itemNum1]
                // 观察者模式：当看见元素的时候，让他加载：把前面预存在data-的数据给拿出来
            const callback = entries => {
                for (let i = 0; i < entries.length; i++) {
                    if (entries[i].isIntersecting) {
                        let item = entries[i].target
                        let data_src0 = item.children[0].getAttribute('data-src')
                        item.children[0].setAttribute('src', data_src0)
                        let data_text0 = item.children[1].firstChild.getAttribute('data-text')
                        item.children[1].firstChild.innerHTML = data_text0
                        let data_text1 = item.children[2].firstElementChild.getAttribute('data-text')
                        item.children[2].firstElementChild.innerHTML = '#' + data_text1
                        let data_src1 = item.children[3].firstElementChild.firstElementChild.getAttribute('data-src')
                        item.children[3].firstElementChild.firstElementChild.setAttribute('src', data_src1)
                        let data_text2 = item.children[3].children[1].getAttribute('data-text')
                        item.children[3].children[1].innerHTML = data_text2
                        let data_number = item.children[3].children[2].children[1].getAttribute('data-number')
                        item.children[3].children[2].children[1].innerHTML = data_number
                        observer.unobserve(item)
                        console.log('触发');
                        subheadings.children[2].addEventListener('click', function() {
                            // 这个本来是同步的，加载图片是异步的，那么只需让排序也放进堆内执行，就可以实现瀑布流，于是给一个很短的定时器来实现
                            setTimeout(function() {
                                let oItem = container1.children
                                let clientwidth = document.documentElement.clientWidth
                                let itemWidth = oItem[0].offsetWidth
                                let num = Math.floor(clientwidth / itemWidth)
                                container1.style.width = num * itemWidth + 1 + 'px'
                                let hrr = []
                                for (let i = 0; i < container1.children.length; i++) {
                                    if (i < num) {
                                        hrr.push(container1.children[i].offsetHeight)
                                        console.log(hrr);
                                    } else {
                                        let minHeight = Math.min(...hrr)
                                        let index = fInArray(minHeight, hrr)
                                        container1.children[i].style.position = 'absolute'
                                        container1.children[i].style.top = minHeight + 'px'
                                        container1.children[i].style.left = index * itemWidth + 'px'
                                        hrr[index] += container1.children[i].offsetHeight
                                    }
                                }
                            }, 100)
                        })
                    }
                }

            }
            const observer = new IntersectionObserver(callback)
            itemNum1Arr.forEach(item => {
                observer.observe(item)
            })

            function fInArray(min, hrr) {
                for (let i = 0; i < hrr.length; i++) {
                    if (hrr[i] == min) {
                        return i
                    }
                }
            }
            //点击盒子让详细内容加载  这里移植性相当的好，只需要改几个把从主页获取的信息的对象换一下就行了
            for (let i = 0; i < container1.children.length; i++) {
                //在获取文章详细信息之前，先检测一下文章有没有被我喜欢
                container1.children[i].addEventListener('click', function() {
                    // linkState初始值是0，如果发送取消喜欢请求后成功取消的话，那么说明已经喜欢过了，让linkState等于1，并发送一次喜欢请求恢复原样
                    //其实可以在这里把喜欢，收藏，关注请求一起发，然后用promise.all一起接收的，可以简化一下逻辑
                    let likingState = 0
                    let p0 = new Promise((resolve, reject) => {
                        console.log(literatureArticle[i]);
                        post('http://175.178.4.54:3007/like/cancelLikeArticle', `article_id=${literatureArticle[i].articleId}`, function(data) {
                            console.log(data);
                            console.log(JSON.parse(data));
                            if (JSON.parse(data).message != '您还没有喜欢过该文章') {
                                post('http://175.178.4.54:3007/like/likeArticle', `article_id=${literatureArticle[i].articleId}`, function(data) {
                                    console.log(data);
                                })
                                likingState = 1
                            } else {
                                likingState = 0
                            }
                            resolve(likingState)
                        })
                    })
                    let p1 = new Promise((resolve, reject) => {
                        post('http://175.178.4.54:3007/star/cancelStarArticles', `article_id=${literatureArticle[i].articleId}`, function(data) {
                            console.log(JSON.parse(data));
                            if (JSON.parse(data).message != '您还没有收藏过该文章') {
                                post('http://175.178.4.54:3007/star/starArticles', `article_id=${literatureArticle[i].articleId}`, function(data) {
                                    console.log(data);
                                })
                                likingStateOfCollect = 1
                            } else {
                                likingStateOfCollect = 0
                            }
                            resolve(likingStateOfCollect)
                        })
                    })
                    let pAll = Promise.all([p0, p1])
                    pAll.then((res) => {
                        [likingState, likingStateOfCollect] = res
                        get('http://175.178.4.54:3007/article/getDetails', `articleId=${literatureArticle[i].articleId}`, function(data) {
                            console.log(JSON.parse(data));
                            let details_title = document.querySelector('#details_title')
                            console.log(details_title);
                            //将除了底下的评论部分的内容放进页面中
                            let str = `
            <div id="othersInformation">
            <div id='othersInformationTitle'>
            <div id="othersGoBack">&#xe8ef;</div>
                <div id="othersHeadPortrait"><img src=${JSON.parse(data).data.avatar}  ></div>
                <div id="othersName_time">
                    <div id="othersName">${JSON.parse(data).data.authorName}</div>
                    <div id="othersTime">${JSON.parse(data).data.time}</div>
                </div>
                <div id="othersFocus">关注</div>
                </div>
                <div id='othersContentBody'>
                <div id="othersImg"><img src=${JSON.parse(data).data.img[0]}  ></div>
                <div id="othersContent">${JSON.parse(data).data.content}</div>
                <div id="othersTag"></div>
                <div id="others_love_comment_collect"><span>&#xe653;</span><span id="commentIcon">&#xe8b4;</span><span id="collectIcon">&#xe8ba;</span></div>
                <div id="fanNum_commentNum">
                    <i id="hotNumberText"><span>热度</span> <span>${JSON.parse(data).data.fanNum}</span></i>
                    <i id="commentNumberText"><span>评论</span> <span>${JSON.parse(data).data.reviewNum}</span></i>
                </div>
                </div>
                <div id="comment">
        <div id="hotComment">热门评论</div>
        <div id="commentDetails"></div>
        <div id="reviewBottom"><input type="text" placeholder="我要发评论">
            <div id='reviewBottomUpvote'>
                <div>&#xe653;</div>
                <div>${JSON.parse(data).data.fanNum}</div>
            </div>
            <div id='reviewBottomReview'>
                <div>&#xe8b4;</div>
                <div>${JSON.parse(data).data.reviewNum}</div>
            </div>
        </div>
        <div id='secondaryComments'><span id='putAway'>&#xe601;</span></div>
        <div id="checkMoreReview">查看更多评论</div>
    </div>
            </div>`
                            details_title.innerHTML = str
                                //文章中的各种数据
                            let hotNumberText = document.querySelector('#hotNumberText')
                            let img = document.querySelector('#othersImg').children[0]
                                //当图片加载不出来的时候隐藏
                            img.addEventListener('error', function() {
                                this.style.display = 'none'
                            })
                            let othersTag = document.querySelector('#othersTag')
                                // 给文章添加标签
                            for (let i = 0; i < JSON.parse(data).data.label.length; i++) {
                                othersTag.innerHTML += `<i>${JSON.parse(data).data.label[i]}</i>`
                            }
                            // 根据 LS,LSC,LSF的值来确定文章中的喜欢，收藏，关注图标的样式
                            let others_love_comment_collect = document.querySelector('#others_love_comment_collect')
                            if (likingState == 1) {
                                others_love_comment_collect.children[0].innerHTML = '&#xe642;'
                            } else {
                                others_love_comment_collect.children[0].innerHTML = '&#xe653;'
                            }
                            if (likingStateOfCollect == 1) {
                                others_love_comment_collect.children[2].innerHTML = '&#xe8c6;'
                            } else {
                                others_love_comment_collect.children[2].innerHTML = '&#xe8ba;'
                            }
                            // if (likingStateOfFocus == 1) {
                            //     let othersFocus = document.querySelector('#othersFocus')
                            //     othersFocus.innerHTML = '已关注'
                            //     othersFocus.className = 'othersFocus_focused'
                            // } else {
                            //     othersFocus.innerHTML = '关注'
                            //     othersFocus.className = ''
                            // }
                            // 加载具体的评论
                            let p1 = new Promise((resolve, reject) => {
                                get('http://175.178.4.54:3007/review/getReviewsByArt', `articleId=${literatureArticle[i].articleId}&page=1&size=20`, function(data) {
                                    let reviewReturn = data
                                    console.log(JSON.parse(reviewReturn));
                                    resolve(reviewReturn)
                                })
                            })
                            p1.then((reviewReturn) => {
                                    // 在热门评论处添加评论
                                    let commentDetails = document.querySelector('#commentDetails')
                                    let checkMoreReview = document.querySelector('#checkMoreReview')
                                    if (JSON.parse(reviewReturn).list.length <= 2) {
                                        let str1 = ''
                                        for (let i = 0; i < JSON.parse(reviewReturn).list.length; i++) {
                                            str1 += `<div class="commentBox">
<div class="othersCommentHeadportrait"><img src=${JSON.parse(reviewReturn).list[i].userInfo.avatar}  ></div>
<div class="othersCommentNickname">${JSON.parse(reviewReturn).list[i].userInfo.userName}</div>
<div class="othersCommentContent">${JSON.parse(reviewReturn).list[i].content}</div>
<div class="othersCommentTime">${JSON.parse(reviewReturn).list[i].time}</div>
<div class="othersMoreComment">-查看更多<span>${JSON.parse(reviewReturn).list[i].childrenReviews.length}</span>条回复-</div>
<div class="othersCommentUpvote">
<div>&#xe653;</div>
<div>${JSON.parse(reviewReturn).list[i].goodNum}</div>
</div>
</div>
</div><div id='layer'></div>`
                                        }
                                        commentDetails.innerHTML = str1
                                            //如果评论的子评论数=0，则隐藏展示子评论的功能
                                        for (let i = 0; i < JSON.parse(reviewReturn).list.length; i++) {
                                            if (JSON.parse(reviewReturn).list[i].childrenReviews.length == 0) {
                                                let othersMoreComment = document.querySelectorAll('.othersMoreComment')
                                                othersMoreComment[i].style.display = 'none'
                                            }
                                        }
                                    }
                                    //当加载更多评论被点击以后，加载更多评论，当二级评论数为0的话，隐藏展开评论
                                    if (JSON.parse(reviewReturn).list.length <= 2) {
                                        checkMoreReview.style.display = 'none'
                                    }
                                    //如果评论的子评论数=0，则隐藏展示子评论的功能
                                    checkMoreReview.addEventListener('click', function() {
                                            let str1 = ``
                                            for (let i = 0; i < JSON.parse(reviewReturn).list.length; i++) {
                                                str1 += `<div class="commentBox">
    <div class="othersCommentHeadportrait"><img src=${JSON.parse(reviewReturn).list[i].userInfo.avatar}  ></div>
    <div class="othersCommentNickname">${JSON.parse(reviewReturn).list[i].userInfo.userName}</div>
    <div class="othersCommentContent">${JSON.parse(reviewReturn).list[i].content}</div>
    <div class="othersCommentTime">${JSON.parse(reviewReturn).list[i].time}</div>
    <div class="othersMoreComment">-查看更多<span>${JSON.parse(reviewReturn).list[i].childrenReviews.length}</span>条回复-</div>
    <div class="othersCommentUpvote">
    <div>&#xe653;</div>
    <div>${JSON.parse(reviewReturn).list[i].goodNum}</div>
    </div></div>
    </div><div id='layer'></div>`
                                            }
                                            commentDetails.innerHTML = str1
                                            checkMoreReview.style.display = 'none'
                                                //如果评论的子评论数=0，则隐藏展示子评论的功能
                                            for (let i = 0; i < JSON.parse(reviewReturn).list.length; i++) {
                                                if (JSON.parse(reviewReturn).list[i].childrenReviews.length == 0) {
                                                    let othersMoreComment = document.querySelectorAll('.othersMoreComment')
                                                    othersMoreComment[i].style.display = 'none'
                                                }
                                            }
                                        })
                                        // 让发评论旁边的小爱心即点赞数与上方的一致
                                    let reviewBottomUpvote = document.querySelector('#reviewBottomUpvote')
                                    console.log();
                                    reviewBottomUpvote.children[0].innerHTML = others_love_comment_collect.children[0].innerHTML
                                    reviewBottomUpvote.children[1].innerHTML = hotNumberText.children[1].innerHTML
                                        // 当上方的爱心被点击时
                                    others_love_comment_collect.children[0].addEventListener('click', function() {
                                            if (likingState == 1) {
                                                post('http://175.178.4.54:3007/like/cancelLikeArticle', `article_id=${literatureArticle[i].articleId}`, function(data) {
                                                    console.log(data);
                                                    others_love_comment_collect.children[0].innerHTML = '&#xe653;'
                                                    likingState = 0
                                                    let hotNumberText = document.querySelector('#hotNumberText')
                                                    hotNumberText.children[1].innerHTML = parseInt(hotNumberText.children[1].innerHTML) - 1
                                                    reviewBottomUpvote.children[0].innerHTML = others_love_comment_collect.children[0].innerHTML
                                                    reviewBottomUpvote.children[1].innerHTML = hotNumberText.children[1].innerHTML
                                                })

                                            } else {
                                                post('http://175.178.4.54:3007/like/likeArticle', `article_id=${literatureArticle[i].articleId}`, function(data) {
                                                    console.log(data);
                                                    others_love_comment_collect.children[0].innerHTML = '&#xe642;'
                                                    likingState = 1

                                                    console.log(hotNumberText);
                                                    hotNumberText.children[1].innerHTML = parseInt(hotNumberText.children[1].innerHTML) + 1
                                                    reviewBottomUpvote.children[0].innerHTML = others_love_comment_collect.children[0].innerHTML
                                                    reviewBottomUpvote.children[1].innerHTML = hotNumberText.children[1].innerHTML
                                                })
                                            }
                                        })
                                        //做下方的发评论
                                    let postReview = reviewBottom.querySelector('input')
                                        //当敲下键盘时，发送评论
                                    postReview.addEventListener('keydown', function(event) {
                                            if (event.keyCode == 13) {
                                                post('http://175.178.4.54:3007/review/submitReview', `content=${postReview.value}&articleId=${indexArticle[i].articleId}`, function() {
                                                    console.log(JSON.parse(data));
                                                    if (JSON.parse(data).status == 200) {
                                                        alert('发布成功')
                                                        postReview.value = ''
                                                    } else {
                                                        alert('未发布成功，请重试')
                                                    }
                                                })
                                                get('http://175.178.4.54:3007/review/getReviewsByArt', `articleId=${indexArticle[i].articleId}&page=1&size=2`, function() {
                                                    console.log(JSON.parse(data));
                                                })
                                            }
                                        })
                                        //仿照爱心点击做一个收藏点击事件
                                    others_love_comment_collect.children[2].addEventListener('click', function() {
                                            if (likingStateOfCollect == 1) {
                                                post('http://175.178.4.54:3007/star/cancelStarArticles', `article_id=${indexArticle[i].articleId}`, function(data) {
                                                    console.log(data);
                                                    others_love_comment_collect.children[2].innerHTML = '&#xe8ba;'
                                                    likingStateOfCollect = 0
                                                })

                                            } else {
                                                post('http://175.178.4.54:3007/star/starArticles', `article_id=${indexArticle[i].articleId}`, function(data) {
                                                    console.log(data);
                                                    others_love_comment_collect.children[2].innerHTML = '&#xe8c6;'
                                                    likingStateOfCollect = 1
                                                })
                                            }
                                        })
                                        //本来是复制上方的爱心点击代码，想到下面的爱心被点击与上方的爱心点击等效，于是将下一个爱心的点击事件与上方爱心点击事件连接起来
                                    reviewBottomUpvote.addEventListener('click', function() {
                                            others_love_comment_collect.children[0].click()
                                        })
                                        //展开更多评论
                                    let othersMoreComment = document.querySelectorAll('.othersMoreComment')
                                    for (let i = 0; i < document.querySelectorAll('.commentBox').length; i++) {
                                        othersMoreComment[i].addEventListener('click', function() {
                                            othersMoreComment[i].style.display = 'none'
                                            let secondaryComments = document.querySelector('#secondaryComments')
                                            let othersInformationTitle = document.querySelector('#othersInformationTitle')
                                            let othersContentBody = document.querySelector('#othersContentBody')
                                            secondaryComments.style.display = 'block'
                                                //写二级评论
                                            let str2 = ''
                                            let layer = document.querySelector('#layer')
                                            for (let j = 0; j < JSON.parse(reviewReturn).list[i].childrenReviews.length; j++) {
                                                let p2 = new Promise((resolve, reject) => {
                                                    get('http://175.178.4.54:3007/userInfo/getUserInfo', `id=${JSON.parse(reviewReturn).list[i].childrenReviews[j].authorId}`, function(data) {
                                                        console.log(JSON.parse(data));
                                                        let userMessage = JSON.parse(data)
                                                        resolve(userMessage)
                                                    })
                                                })
                                                p2.then((userMessage) => {
                                                    for (let k = 0; k < JSON.parse(reviewReturn).list[i].childrenReviews.length; k++) {
                                                        str2 += `<div class="commentBox">
                                                            <div class="othersSecondaryCommentHeadportrait"><img src=${userMessage.data.avatar} ></div>
                                                            <div class="othersCommentNickname">${userMessage.data.username}</div>
                                                            <div class="othersCommentContent">${JSON.parse(reviewReturn).list[i].childrenReviews[j].content}</div>
                                                            <div class="othersCommentTime">${JSON.parse(reviewReturn).list[i].childrenReviews[j].time}</div>
                                                            <div class="othersCommentUpvote">
                                                            <div>&#xe653;</div>
                                                            <div>${JSON.parse(reviewReturn).list[i].childrenReviews[j].goodNum}</div>
                                                            </div></div>
                                                            `
                                                    }
                                                    secondaryComments.innerHTML += str2
                                                    layer.style.display = 'block'
                                                    let putAway = document.querySelector('#putAway')
                                                    putAway.addEventListener('click', function() {
                                                        secondaryComments.style.display = 'none'
                                                        layer.style.display = 'none'
                                                        othersMoreComment[i].style.display = 'block'
                                                    })
                                                }, () => {})

                                            }

                                        })
                                    }
                                }, () => {})
                                //点进文章页以后，当前显示的页面消失，替换成文章页
                            details_title.style.display = 'block'
                            index.style.display = 'none'
                            footer.style.display = 'none'
                            let othersGoBack = document.querySelector('#othersGoBack')
                            othersGoBack.addEventListener('click', function() {
                                details_title.style.display = 'none'
                                index.style.display = 'block'
                                footer.style.display = 'flex'
                            })
                        })


                    }, () => {})
                })
            }
        },
        () => {}
    )
}

getLiteratureArticle()


function getDrawingArticle() {

    let p = new Promise((resolve, reject) => {
        //这里才发现要做分页效果，但是来不及了  应该是小问题吧，我现在搞明白观察者模式了，其实感觉不分页也还行
        get('http://175.178.4.54:3007/article/getArticle', 'type=绘画&page=1&size=100000', function(data) {
            if (localStorage.getItem('drawingArticleNumber')) {
                localStorage.removeItem('drawingArticleNumber')
                localStorage.setItem('drawingArticleNumber', JSON.parse(data).data.articleList.length)
            } else {
                localStorage.setItem('drawingArticleNumber', JSON.parse(data).data.articleList.length)
            }
            drawingArticle = JSON.parse(data).data.articleList
            resolve(drawingArticle)
        })

    })
    p.then(
        // 字符串拼接创建多个盒子
        (drawingArticle) => {
            let str = ''
            for (let i = 0; i < drawingArticle.length; i++) {
                str += `<div class="item"><img data-src=${drawingArticle[i].avatar}>
    <div class="text"><span data-text=${drawingArticle[i].title}></span><span class="more">&#xe600;</span></div>
    <div class="tag"><div data-text=${drawingArticle[i].label[0]}></div></div>
    <div class="bottomRow">
    <div class="headPortrait"><img  data-src=${drawingArticle[i].cover}></div>
    <div class="nickname" data-text=${drawingArticle[i].username}></div>
    <div class="upvote"> <div class="heart">&#xe653;</div> <div class="number" data-number=${drawingArticle[i].fanNum}></div>
    </div>
    </div>
    </div>`
            }
            container2.innerHTML = str
            itemNum2 = container2.children
            itemNum2Arr = [...itemNum2]
                // 当看见元素的时候，让他加载（观察者）
            const callback = entries => {
                for (let i = 0; i < entries.length; i++) {
                    if (entries[i].isIntersecting) {
                        let item = entries[i].target
                        let data_src0 = item.children[0].getAttribute('data-src')
                        item.children[0].setAttribute('src', data_src0)
                        let data_text0 = item.children[1].firstChild.getAttribute('data-text')
                        item.children[1].firstChild.innerHTML = data_text0
                        let data_text1 = item.children[2].firstElementChild.getAttribute('data-text')
                        item.children[2].firstElementChild.innerHTML = '#' + data_text1
                        let data_src1 = item.children[3].firstElementChild.firstElementChild.getAttribute('data-src')
                        item.children[3].firstElementChild.firstElementChild.setAttribute('src', data_src1)
                        let data_text2 = item.children[3].children[1].getAttribute('data-text')
                        item.children[3].children[1].innerHTML = data_text2
                        let data_number = item.children[3].children[2].children[1].getAttribute('data-number')
                        item.children[3].children[2].children[1].innerHTML = data_number
                        observer.unobserve(item)
                        console.log('触发');
                        subheadings.children[3].addEventListener('click', function() {
                            // 这个本来是同步的，加载图片是异步的，那么只需让排序也放进堆内执行，就可以实现瀑布流，于是给一个很短的定时器来实现
                            setTimeout(function() {
                                let oItem = container2.children
                                let clientwidth = document.documentElement.clientWidth
                                let itemWidth = oItem[0].offsetWidth
                                let num = Math.floor(clientwidth / itemWidth)
                                container2.style.width = num * itemWidth + 1 + 'px'
                                let hrr = []
                                for (let i = 0; i < container2.children.length; i++) {
                                    if (i < num) {
                                        hrr.push(container2.children[i].offsetHeight)
                                        console.log(hrr);
                                    } else {
                                        let minHeight = Math.min(...hrr)
                                        let index = fInArray(minHeight, hrr)
                                        container2.children[i].style.position = 'absolute'
                                        container2.children[i].style.top = minHeight + 'px'
                                        container2.children[i].style.left = index * itemWidth + 'px'
                                        hrr[index] += container2.children[i].offsetHeight
                                    }
                                }
                            }, 100)
                        })
                    }
                }

            }
            const observer = new IntersectionObserver(callback)
            itemNum2Arr.forEach(item => {
                observer.observe(item)
            })

            function fInArray(min, hrr) {
                for (let i = 0; i < hrr.length; i++) {
                    if (hrr[i] == min) {
                        return i
                    }
                }
            }
            //点击盒子让详细内容加载  这里移植性相当的好，只需要改几个把从主页获取的信息的对象换一下就行了
            for (let i = 0; i < container2.children.length; i++) {
                //在获取文章详细信息之前，先检测一下文章有没有被我喜欢
                container2.children[i].addEventListener('click', function() {
                    // linkState初始值是0，如果发送取消喜欢请求后成功取消的话，那么说明已经喜欢过了，让linkState等于1，并发送一次喜欢请求恢复原样
                    //其实可以在这里把喜欢，收藏，关注请求一起发，然后用promise.all一起接收的，可以简化一下逻辑
                    let likingState = 0
                    let p0 = new Promise((resolve, reject) => {
                        console.log(drawingArticle[i]);
                        post('http://175.178.4.54:3007/like/cancelLikeArticle', `article_id=${drawingArticle[i].articleId}`, function(data) {
                            console.log(data);
                            console.log(JSON.parse(data));
                            if (JSON.parse(data).message != '您还没有喜欢过该文章') {
                                post('http://175.178.4.54:3007/like/likeArticle', `article_id=${drawingArticle[i].articleId}`, function(data) {
                                    console.log(data);
                                })
                                likingState = 1
                            } else {
                                likingState = 0
                            }
                            resolve(likingState)
                        })
                    })
                    let p1 = new Promise((resolve, reject) => {
                        post('http://175.178.4.54:3007/star/cancelStarArticles', `article_id=${drawingArticle[i].articleId}`, function(data) {
                            console.log(JSON.parse(data));
                            if (JSON.parse(data).message != '您还没有收藏过该文章') {
                                post('http://175.178.4.54:3007/star/starArticles', `article_id=${drawingArticle[i].articleId}`, function(data) {
                                    console.log(data);
                                })
                                likingStateOfCollect = 1
                            } else {
                                likingStateOfCollect = 0
                            }
                            resolve(likingStateOfCollect)
                        })
                    })
                    let pAll = Promise.all([p0, p1])
                    pAll.then((res) => {
                        [likingState, likingStateOfCollect] = res
                        get('http://175.178.4.54:3007/article/getDetails', `articleId=${drawingArticle[i].articleId}`, function(data) {
                            console.log(JSON.parse(data));
                            let details_title = document.querySelector('#details_title')
                            console.log(details_title);
                            //将除了底下的评论部分的内容放进页面中
                            let str = `
            <div id="othersInformation">
            <div id='othersInformationTitle'>
            <div id="othersGoBack">&#xe8ef;</div>
                <div id="othersHeadPortrait"><img src=${JSON.parse(data).data.avatar}  ></div>
                <div id="othersName_time">
                    <div id="othersName">${JSON.parse(data).data.authorName}</div>
                    <div id="othersTime">${JSON.parse(data).data.time}</div>
                </div>
                <div id="othersFocus">关注</div>
                </div>
                <div id='othersContentBody'>
                <div id="othersImg"><img src=${JSON.parse(data).data.img[0]}  ></div>
                <div id="othersContent">${JSON.parse(data).data.content}</div>
                <div id="othersTag"></div>
                <div id="others_love_comment_collect"><span>&#xe653;</span><span id="commentIcon">&#xe8b4;</span><span id="collectIcon">&#xe8ba;</span></div>
                <div id="fanNum_commentNum">
                    <i id="hotNumberText"><span>热度</span> <span>${JSON.parse(data).data.fanNum}</span></i>
                    <i id="commentNumberText"><span>评论</span> <span>${JSON.parse(data).data.reviewNum}</span></i>
                </div>
                </div>
                <div id="comment">
        <div id="hotComment">热门评论</div>
        <div id="commentDetails"></div>
        <div id="reviewBottom"><input type="text" placeholder="我要发评论">
            <div id='reviewBottomUpvote'>
                <div>&#xe653;</div>
                <div>${JSON.parse(data).data.fanNum}</div>
            </div>
            <div id='reviewBottomReview'>
                <div>&#xe8b4;</div>
                <div>${JSON.parse(data).data.reviewNum}</div>
            </div>
        </div>
        <div id='secondaryComments'><span id='putAway'>&#xe601;</span></div>
        <div id="checkMoreReview">查看更多评论</div>
    </div>
            </div>`
                            details_title.innerHTML = str
                                //文章中的各种数据
                            let hotNumberText = document.querySelector('#hotNumberText')
                            let img = document.querySelector('#othersImg').children[0]
                                //当图片加载不出来的时候隐藏
                            img.addEventListener('error', function() {
                                this.style.display = 'none'
                            })
                            let othersTag = document.querySelector('#othersTag')
                            for (let i = 0; i < JSON.parse(data).data.label.length; i++) {
                                othersTag.innerHTML += `<i>${JSON.parse(data).data.label[i]}</i>`
                            }
                            let others_love_comment_collect = document.querySelector('#others_love_comment_collect')
                            if (likingState == 1) {
                                others_love_comment_collect.children[0].innerHTML = '&#xe642;'
                            } else {
                                others_love_comment_collect.children[0].innerHTML = '&#xe653;'
                            }
                            if (likingStateOfCollect == 1) {
                                others_love_comment_collect.children[2].innerHTML = '&#xe8c6;'
                            } else {
                                others_love_comment_collect.children[2].innerHTML = '&#xe8ba;'
                            }
                            // 加载具体的评论
                            let p1 = new Promise((resolve, reject) => {
                                get('http://175.178.4.54:3007/review/getReviewsByArt', `articleId=${drawingArticle[i].articleId}&page=1&size=20`, function(data) {
                                    let reviewReturn = data
                                    console.log(JSON.parse(reviewReturn));
                                    resolve(reviewReturn)
                                })
                            })
                            p1.then((reviewReturn) => {
                                // 在热门评论处添加评论
                                let commentDetails = document.querySelector('#commentDetails')
                                let checkMoreReview = document.querySelector('#checkMoreReview')
                                if (JSON.parse(reviewReturn).list.length <= 2 && JSON.parse(reviewReturn).list.length != 0) {
                                    let str1 = ''
                                    for (let i = 0; i < JSON.parse(reviewReturn).list.length; i++) {
                                        str1 += `<div class="commentBox">
<div class="othersCommentHeadportrait"><img src=${JSON.parse(reviewReturn).list[i].userInfo.avatar}  ></div>
<div class="othersCommentNickname">${JSON.parse(reviewReturn).list[i].userInfo.userName}</div>
<div class="othersCommentContent">${JSON.parse(reviewReturn).list[i].content}</div>
<div class="othersCommentTime">${JSON.parse(reviewReturn).list[i].time}</div>
<div class="othersMoreComment">-查看更多<span>${JSON.parse(reviewReturn).list[i].childrenReviews.length}</span>条回复-</div>
<div class="othersCommentUpvote">
<div>&#xe653;</div>
<div>${JSON.parse(reviewReturn).list[i].goodNum}</div>
</div>
</div>
</div><div id='layer'></div>`
                                    }
                                    commentDetails.innerHTML = str1
                                        //如果评论数小于等于2，则隐藏展示更多评论的功能
                                    for (let i = 0; i < JSON.parse(reviewReturn).list.length; i++) {
                                        if (JSON.parse(reviewReturn).list[i].childrenReviews.length == 0) {
                                            let othersMoreComment = document.querySelectorAll('.othersMoreComment')
                                            othersMoreComment[i].style.display = 'none'
                                        }
                                    }
                                    checkMoreReview.style.display = 'none'
                                } else if (JSON.parse(reviewReturn).list.length == 0) {
                                    commentDetails.innerHTML = ``
                                    checkMoreReview.style.display = 'none'
                                } else {
                                    // 当评论数大于2的情况，加载两项评论，如果二级评论数为0的话，隐藏展开评论
                                    //先加载两项，等点击加载更多以后再显示全部
                                    let str1 = ''
                                    for (let i = 0; i < 2; i++) {
                                        str1 += `<div class="commentBox">
<div class="othersCommentHeadportrait"><img src=${JSON.parse(reviewReturn).list[i].userInfo.avatar}  ></div>
<div class="othersCommentNickname">${JSON.parse(reviewReturn).list[i].userInfo.userName}</div>
<div class="othersCommentContent">${JSON.parse(reviewReturn).list[i].content}</div>
<div class="othersCommentTime">${JSON.parse(reviewReturn).list[i].time}</div>
<div class="othersMoreComment">-查看更多<span>${JSON.parse(reviewReturn).list[i].childrenReviews.length}</span>条回复-</div>
<div class="othersCommentUpvote">
<div>&#xe653;</div>
<div>${JSON.parse(reviewReturn).list[i].goodNum}</div>
</div>
</div>
</div><div id='layer'></div>`
                                    }
                                    commentDetails.innerHTML = str1
                                        //如果评论的子评论数=0，则隐藏展示子评论的功能
                                    for (let i = 0; i < 2; i++) {
                                        if (JSON.parse(reviewReturn).list[i].childrenReviews.length == 0) {
                                            let othersMoreComment = document.querySelectorAll('.othersMoreComment')
                                            othersMoreComment[i].style.display = 'none'
                                        }
                                    }
                                    //当加载更多评论被点击以后，加载更多评论，当二级评论数为0的话，隐藏展开评论
                                    checkMoreReview.addEventListener('click', function() {
                                        let str1 = ``
                                        for (let i = 0; i < JSON.parse(reviewReturn).list.length; i++) {
                                            str1 += `<div class="commentBox">
    <div class="othersCommentHeadportrait"><img src=${JSON.parse(reviewReturn).list[i].userInfo.avatar}  ></div>
    <div class="othersCommentNickname">${JSON.parse(reviewReturn).list[i].userInfo.userName}</div>
    <div class="othersCommentContent">${JSON.parse(reviewReturn).list[i].content}</div>
    <div class="othersCommentTime">${JSON.parse(reviewReturn).list[i].time}</div>
    <div class="othersMoreComment">-查看更多<span>${JSON.parse(reviewReturn).list[i].childrenReviews.length}</span>条回复-</div>
    <div class="othersCommentUpvote">
    <div>&#xe653;</div>
    <div>${JSON.parse(reviewReturn).list[i].goodNum}</div>
    </div></div>
    </div><div id='layer'></div>`
                                        }
                                        commentDetails.innerHTML = str1
                                        checkMoreReview.style.display = 'none'
                                            //如果评论的子评论数=0，则隐藏展示子评论的功能
                                        for (let i = 0; i < JSON.parse(reviewReturn).list.length; i++) {
                                            if (JSON.parse(reviewReturn).list[i].childrenReviews.length == 0) {
                                                let othersMoreComment = document.querySelectorAll('.othersMoreComment')
                                                othersMoreComment[i].style.display = 'none'
                                            }
                                        }
                                    })
                                }
                                // 让发评论旁边的小爱心即点赞数与上方的一致
                                let reviewBottomUpvote = document.querySelector('#reviewBottomUpvote')
                                reviewBottomUpvote.children[0].innerHTML = others_love_comment_collect.children[0].innerHTML
                                reviewBottomUpvote.children[1].innerHTML = hotNumberText.children[1].innerHTML
                                    // 当上方的爱心被点击时
                                others_love_comment_collect.children[0].addEventListener('click', function() {
                                        if (likingState == 1) {
                                            post('http://175.178.4.54:3007/like/cancelLikeArticle', `article_id=${drawingArticle[i].articleId}`, function(data) {
                                                console.log(data);
                                                others_love_comment_collect.children[0].innerHTML = '&#xe653;'
                                                likingState = 0
                                                let hotNumberText = document.querySelector('#hotNumberText')
                                                hotNumberText.children[1].innerHTML = parseInt(hotNumberText.children[1].innerHTML) - 1
                                                reviewBottomUpvote.children[0].innerHTML = others_love_comment_collect.children[0].innerHTML
                                                reviewBottomUpvote.children[1].innerHTML = hotNumberText.children[1].innerHTML
                                            })

                                        } else {
                                            post('http://175.178.4.54:3007/like/likeArticle', `article_id=${drawingArticle[i].articleId}`, function(data) {
                                                console.log(data);
                                                others_love_comment_collect.children[0].innerHTML = '&#xe642;'
                                                likingState = 1
                                                console.log(hotNumberText);
                                                hotNumberText.children[1].innerHTML = parseInt(hotNumberText.children[1].innerHTML) + 1
                                                reviewBottomUpvote.children[0].innerHTML = others_love_comment_collect.children[0].innerHTML
                                                reviewBottomUpvote.children[1].innerHTML = hotNumberText.children[1].innerHTML
                                            })
                                        }
                                    })
                                    //做下方的发评论
                                let postReview = reviewBottom.querySelector('input')
                                    //当敲下键盘时，发送评论
                                postReview.addEventListener('keydown', function(event) {
                                        if (event.keyCode == 13) {
                                            post('http://175.178.4.54:3007/review/submitReview', `content=${postReview.value}&articleId=${indexArticle[i].articleId}`, function() {
                                                console.log(JSON.parse(data));
                                                if (JSON.parse(data).status == 200) {
                                                    alert('发布成功')
                                                    postReview.value = ''
                                                } else {
                                                    alert('未发布成功，请重试')
                                                }
                                            })
                                            get('http://175.178.4.54:3007/review/getReviewsByArt', `articleId=${indexArticle[i].articleId}&page=1&size=2`, function() {
                                                console.log(JSON.parse(data));
                                            })
                                        }
                                    })
                                    //仿照爱心点击做一个收藏点击事件
                                others_love_comment_collect.children[2].addEventListener('click', function() {
                                        if (likingStateOfCollect == 1) {
                                            post('http://175.178.4.54:3007/star/cancelStarArticles', `article_id=${indexArticle[i].articleId}`, function(data) {
                                                console.log(data);
                                                others_love_comment_collect.children[2].innerHTML = '&#xe8ba;'
                                                likingStateOfCollect = 0
                                            })

                                        } else {
                                            post('http://175.178.4.54:3007/star/starArticles', `article_id=${indexArticle[i].articleId}`, function(data) {
                                                console.log(data);
                                                others_love_comment_collect.children[2].innerHTML = '&#xe8c6;'
                                                likingStateOfCollect = 1
                                            })
                                        }
                                    })
                                    //本来是复制上方的爱心点击代码，想到下面的爱心被点击与上方的爱心点击等效，于是将下一个爱心的点击事件与上方爱心点击事件连接起来
                                reviewBottomUpvote.addEventListener('click', function() {
                                    others_love_comment_collect.children[0].click()
                                })
                                let othersMoreComment = document.querySelectorAll('.othersMoreComment')
                                for (let i = 0; i < document.querySelectorAll('.commentBox').length; i++) {
                                    othersMoreComment[i].addEventListener('click', function() {
                                        othersMoreComment[i].style.display = 'none'
                                        let secondaryComments = document.querySelector('#secondaryComments')
                                        let othersInformationTitle = document.querySelector('#othersInformationTitle')
                                        let othersContentBody = document.querySelector('#othersContentBody')
                                        secondaryComments.style.display = 'block'
                                            //写二级评论
                                        let str2 = ''
                                        let layer = document.querySelector('#layer')
                                        for (let j = 0; j < JSON.parse(reviewReturn).list[i].childrenReviews.length; j++) {
                                            let p2 = new Promise((resolve, reject) => {
                                                get('http://175.178.4.54:3007/userInfo/getUserInfo', `id=${JSON.parse(reviewReturn).list[i].childrenReviews[j].authorId}`, function(data) {
                                                    console.log(JSON.parse(data));
                                                    let userMessage = JSON.parse(data)
                                                    resolve(userMessage)
                                                })
                                            })
                                            p2.then((userMessage) => {
                                                for (let k = 0; k < JSON.parse(reviewReturn).list[i].childrenReviews.length; k++) {
                                                    str2 += `<div class="commentBox">
                                                            <div class="othersSecondaryCommentHeadportrait"><img src=${userMessage.data.avatar}  ></div>
                                                            <div class="othersCommentNickname">${userMessage.data.username}</div>
                                                            <div class="othersCommentContent">${JSON.parse(reviewReturn).list[i].childrenReviews[j].content}</div>
                                                            <div class="othersCommentTime">${JSON.parse(reviewReturn).list[i].childrenReviews[j].time}</div>
                                                            <div class="othersCommentUpvote">
                                                            <div>&#xe653;</div>
                                                            <div>${JSON.parse(reviewReturn).list[i].childrenReviews[j].goodNum}</div>
                                                            </div></div>`
                                                }
                                                secondaryComments.innerHTML += str2
                                                layer.style.display = 'block'
                                                let putAway = document.querySelector('#putAway')
                                                putAway.addEventListener('click', function() {
                                                    secondaryComments.style.display = 'none'
                                                    layer.style.display = 'none'
                                                    othersMoreComment[i].style.display = 'block'
                                                })
                                            }, () => {})
                                        }
                                    })
                                }
                            }, () => {})
                            details_title.style.display = 'block'
                            index.style.display = 'none'
                            footer.style.display = 'none'
                                //点进文章页以后，当前显示的页面消失，替换成文章页
                            let othersGoBack = document.querySelector('#othersGoBack')
                            othersGoBack.addEventListener('click', function() {
                                details_title.style.display = 'none'
                                index.style.display = 'block'
                                footer.style.display = 'flex'
                            })
                        })


                    }, () => {})

                })
            }
        },
        () => {}
    )
}

getDrawingArticle()

function getPhotographArticle() {

    let p = new Promise((resolve, reject) => {

        get('http://175.178.4.54:3007/article/getArticle', 'type=摄影&page=1&size=10', function(data) {
            if (localStorage.getItem('photographArticleNumber')) {
                localStorage.removeItem('photographArticleNumber')
                localStorage.setItem('photographArticleNumber', JSON.parse(data).data.articleList.length)
            } else {
                localStorage.setItem('photographArticleNumber', JSON.parse(data).data.articleList.length)
            }
            photographArticle = JSON.parse(data).data.articleList
            resolve(photographArticle)
        })

    })
    p.then(
        // 字符串拼接创建多个盒子
        (photographArticle) => {
            let str = ''
            for (let i = 0; i < photographArticle.length; i++) {
                str += `<div class="item"><img data-src=${photographArticle[i].avatar}>
    <div class="text"><span data-text=${photographArticle[i].title}></span><span class="more">&#xe600;</span></div>
    <div class="tag"><div data-text=${photographArticle[i].label[0]}></div></div>
    <div class="bottomRow">
    <div class="headPortrait"><img  data-src=${photographArticle[i].cover}></div>
    <div class="nickname" data-text=${photographArticle[i].username}></div>
    <div class="upvote"> <div class="heart">&#xe653;</div> <div class="number" data-number=${photographArticle[i].fanNum}></div>
    </div>
    </div>
    </div>`
            }
            container3.innerHTML = str
            itemNum3 = container3.children
            itemNum3Arr = [...itemNum3]
                // 当看见元素的时候，让他加载（观察者）
            const callback = entries => {
                for (let i = 0; i < entries.length; i++) {
                    if (entries[i].isIntersecting) {
                        let item = entries[i].target
                        let data_src0 = item.children[0].getAttribute('data-src')
                        item.children[0].setAttribute('src', data_src0)
                        let data_text0 = item.children[1].firstChild.getAttribute('data-text')
                        item.children[1].firstChild.innerHTML = data_text0
                        let data_text1 = item.children[2].firstElementChild.getAttribute('data-text')
                        item.children[2].firstElementChild.innerHTML = '#' + data_text1
                        let data_src1 = item.children[3].firstElementChild.firstElementChild.getAttribute('data-src')
                        item.children[3].firstElementChild.firstElementChild.setAttribute('src', data_src1)
                        let data_text2 = item.children[3].children[1].getAttribute('data-text')
                        item.children[3].children[1].innerHTML = data_text2
                        let data_number = item.children[3].children[2].children[1].getAttribute('data-number')
                        item.children[3].children[2].children[1].innerHTML = data_number
                        observer.unobserve(item)
                        console.log('触发');
                        subheadings.children[4].addEventListener('click', function() {
                            // 这个本来是同步的，加载图片是异步的，那么只需让排序也放进堆内执行，就可以实现瀑布流，于是给一个很短的定时器来实
                            setTimeout(function() {
                                let oItem = container4.children
                                let clientwidth = document.documentElement.clientWidth
                                let itemWidth = oItem[0].offsetWidth
                                let num = Math.floor(clientwidth / itemWidth)
                                container3.style.width = num * itemWidth + 1 + 'px'
                                let hrr = []
                                for (let i = 0; i < container3.children.length; i++) {
                                    if (i < num) {
                                        hrr.push(container3.children[i].offsetHeight)
                                        console.log(hrr);
                                    } else {
                                        let minHeight = Math.min(...hrr)
                                        let index = fInArray(minHeight, hrr)
                                        container3.children[i].style.position = 'absolute'
                                        container3.children[i].style.top = minHeight + 'px'
                                        container3.children[i].style.left = index * itemWidth + 'px'
                                        hrr[index] += container3.children[i].offsetHeight
                                    }
                                }
                            }, 100)
                        })
                    }
                }
            }
            const observer = new IntersectionObserver(callback)
            itemNum3Arr.forEach(item => {
                observer.observe(item)
            })

            function fInArray(min, hrr) {
                for (let i = 0; i < hrr.length; i++) {
                    if (hrr[i] == min) {
                        return i
                    }
                }
            }
            //点击盒子让详细内容加载  这里移植性相当的好，只需要改几个把从主页获取的信息的对象换一下就行了
            for (let i = 0; i < container3.children.length; i++) {
                //在获取文章详细信息之前，先检测一下文章有没有被我喜欢
                container3.children[i].addEventListener('click', function() {
                    // linkState初始值是0，如果发送取消喜欢请求后成功取消的话，那么说明已经喜欢过了，让linkState等于1，并发送一次喜欢请求恢复原样
                    let likingState = 0
                    let p0 = new Promise((resolve, reject) => {
                        console.log(photographArticle[i]);
                        post('http://175.178.4.54:3007/like/cancelLikeArticle', `article_id=${photographArticle[i].articleId}`, function(data) {
                            console.log(data);
                            console.log(JSON.parse(data));
                            if (JSON.parse(data).message != '您还没有喜欢过该文章') {
                                post('http://175.178.4.54:3007/like/likeArticle', `article_id=${photographArticle[i].articleId}`, function(data) {
                                    console.log(data);
                                })
                                likingState = 1
                            } else {
                                likingState = 0
                            }
                            resolve(likingState)
                        })
                    })

                    let p1 = new Promise((resolve, reject) => {
                        post('http://175.178.4.54:3007/star/cancelStarArticles', `article_id=${photographArticle[i].articleId}`, function(data) {
                            console.log(JSON.parse(data));
                            if (JSON.parse(data).message != '您还没有收藏过该文章') {
                                post('http://175.178.4.54:3007/star/starArticles', `article_id=${photographArticle[i].articleId}`, function(data) {
                                    console.log(data);
                                })
                                likingStateOfCollect = 1
                            } else {
                                likingStateOfCollect = 0
                            }
                            resolve(likingStateOfCollect)
                        })
                    })
                    let pAll = Promise.all([p0, p1])
                    pAll.then((res) => {
                        [likingState, likingStateOfCollect] = res
                        get('http://175.178.4.54:3007/article/getDetails', `articleId=${photographArticle[i].articleId}`, function(data) {
                            console.log(JSON.parse(data));
                            let details_title = document.querySelector('#details_title')
                            console.log(details_title);
                            //将除了底下的评论部分的内容放进页面中
                            let str = `
            <div id="othersInformation">
            <div id='othersInformationTitle'>
            <div id="othersGoBack">&#xe8ef;</div>
                <div id="othersHeadPortrait"><img src=${JSON.parse(data).data.avatar}  ></div>
                <div id="othersName_time">
                    <div id="othersName">${JSON.parse(data).data.authorName}</div>
                    <div id="othersTime">${JSON.parse(data).data.time}</div>
                </div>
                <div id="othersFocus">关注</div>
                </div>
                <div id='othersContentBody'>
                <div id="othersImg"><img src=${JSON.parse(data).data.img[0]}  ></div>
                <div id="othersContent">${JSON.parse(data).data.content}</div>
                <div id="othersTag"></div>
                <div id="others_love_comment_collect"><span>&#xe653;</span><span id="commentIcon">&#xe8b4;</span><span id="collectIcon">&#xe8ba;</span></div>
                <div id="fanNum_commentNum">
                    <i id="hotNumberText"><span>热度</span> <span>${JSON.parse(data).data.fanNum}</span></i>
                    <i id="commentNumberText"><span>评论</span> <span>${JSON.parse(data).data.reviewNum}</span></i>
                </div>
                </div>
                <div id="comment">
        <div id="hotComment">热门评论</div>
        <div id="commentDetails"></div>
        <div id="reviewBottom"><input type="text" placeholder="我要发评论">
            <div id='reviewBottomUpvote'>
                <div>&#xe653;</div>
                <div>${JSON.parse(data).data.fanNum}</div>
            </div>
            <div id='reviewBottomReview'>
                <div>&#xe8b4;</div>
                <div>${JSON.parse(data).data.reviewNum}</div>
            </div>
        </div>
        <div id='secondaryComments'><span id='putAway'>&#xe601;</span></div>
        <div id="checkMoreReview">查看更多评论</div>
    </div>
            </div>`
                            details_title.innerHTML = str
                                //文章中的各种数据
                            let hotNumberText = document.querySelector('#hotNumberText')
                            let img = document.querySelector('#othersImg').children[0]
                                //当图片加载不出来的时候隐藏
                            img.addEventListener('error', function() {
                                this.style.display = 'none'
                            })
                            let othersTag = document.querySelector('#othersTag')
                                // 给文章添加标签
                            for (let i = 0; i < JSON.parse(data).data.label.length; i++) {
                                othersTag.innerHTML += `<i>${JSON.parse(data).data.label[i]}</i>`
                            }
                            let others_love_comment_collect = document.querySelector('#others_love_comment_collect')
                                // 根据 LS,LSC,LSF的值来确定文章中的喜欢，收藏，关注图标的样式
                            if (likingState == 1) {
                                others_love_comment_collect.children[0].innerHTML = '&#xe642;'
                            } else {
                                others_love_comment_collect.children[0].innerHTML = '&#xe653;'
                            }
                            if (likingStateOfCollect == 1) {
                                others_love_comment_collect.children[2].innerHTML = '&#xe8c6;'
                            } else {
                                others_love_comment_collect.children[2].innerHTML = '&#xe8ba;'
                            }
                            // if (likingStateOfFocus == 1) {
                            //     let othersFocus = document.querySelector('#othersFocus')
                            //     othersFocus.innerHTML = '已关注'
                            //     othersFocus.className = 'othersFocus_focused'
                            // } else {
                            //     othersFocus.innerHTML = '关注'
                            //     othersFocus.className = ''
                            // }
                            // 加载具体的评论
                            let p1 = new Promise((resolve, reject) => {
                                get('http://175.178.4.54:3007/review/getReviewsByArt', `articleId=${photographArticle[i].articleId}&page=1&size=2`, function(data) {
                                    let reviewReturn = data
                                    console.log(JSON.parse(reviewReturn));
                                    resolve(reviewReturn)
                                })
                            })
                            p1.then((reviewReturn) => {
                                    // 在热门评论处添加评论
                                    let commentDetails = document.querySelector('#commentDetails')
                                    let checkMoreReview = document.querySelector('#checkMoreReview')
                                    if (JSON.parse(reviewReturn).list.length <= 2 && JSON.parse(reviewReturn).list.length != 0) {
                                        let str1 = ''
                                        for (let i = 0; i < JSON.parse(reviewReturn).list.length; i++) {
                                            str1 += `<div class="commentBox">
<div class="othersCommentHeadportrait"><img src=${JSON.parse(reviewReturn).list[i].userInfo.avatar}  ></div>
<div class="othersCommentNickname">${JSON.parse(reviewReturn).list[i].userInfo.userName}</div>
<div class="othersCommentContent">${JSON.parse(reviewReturn).list[i].content}</div>
<div class="othersCommentTime">${JSON.parse(reviewReturn).list[i].time}</div>
<div class="othersMoreComment">-查看更多<span>${JSON.parse(reviewReturn).list[i].childrenReviews.length}</span>条回复-</div>
<div class="othersCommentUpvote">
<div>&#xe653;</div>
<div>${JSON.parse(reviewReturn).list[i].goodNum}</div>
</div>
</div>
</div><div id='layer'></div>`
                                        }
                                        commentDetails.innerHTML = str1
                                            //如果评论数小于等于2，则隐藏展示更多评论的功能
                                        for (let i = 0; i < JSON.parse(reviewReturn).list.length; i++) {
                                            if (JSON.parse(reviewReturn).list[i].childrenReviews.length == 0 && JSON.parse(reviewReturn).list.length != 0) {
                                                let othersMoreComment = document.querySelectorAll('.othersMoreComment')
                                                othersMoreComment[i].style.display = 'none'
                                            }
                                        }
                                        //当加载更多评论被点击以后，加载更多评论，当二级评论数为0的话，隐藏展开评论
                                        checkMoreReview.style.display = 'none'
                                    } else if (JSON.parse(reviewReturn).list.length == 0) {
                                        checkMoreReview.style.display = 'none'
                                    } else {
                                        // 当评论数大于2的情况，加载两项评论，如果二级评论数为0的话，隐藏展开评论
                                        //先加载两项，等点击加载更多以后再显示全部
                                        let str1 = ''
                                        for (let i = 0; i < 2; i++) {
                                            str1 += `<div class="commentBox">
    <div class="othersCommentHeadportrait"><img src=${JSON.parse(reviewReturn).list[i].userInfo.avatar}  ></div>
    <div class="othersCommentNickname">${JSON.parse(reviewReturn).list[i].userInfo.userName}</div>
    <div class="othersCommentContent">${JSON.parse(reviewReturn).list[i].content}</div>
    <div class="othersCommentTime">${JSON.parse(reviewReturn).list[i].time}</div>
    <div class="othersMoreComment">-查看更多<span>${JSON.parse(reviewReturn).list[i].childrenReviews.length}</span>条回复-</div>
    <div class="othersCommentUpvote">
    <div>&#xe653;</div>
    <div>${JSON.parse(reviewReturn).list[i].goodNum}</div>
    </div>
    </div>
    </div><div id='layer'></div>`
                                        }
                                        commentDetails.innerHTML = str1
                                            //如果评论的子评论数=0，则隐藏展示子评论的功能
                                        for (let i = 0; i < 2; i++) {
                                            if (JSON.parse(reviewReturn).list[i].childrenReviews.length == 0) {
                                                let othersMoreComment = document.querySelectorAll('.othersMoreComment')
                                                othersMoreComment[i].style.display = 'none'
                                            }
                                        }
                                        //当加载更多评论被点击以后，加载更多评论，当二级评论数为0的话，隐藏展开评论
                                        checkMoreReview.addEventListener('click', function() {
                                            let str1 = ``
                                            for (let i = 0; i < JSON.parse(reviewReturn).list.length; i++) {
                                                str1 += `<div class="commentBox">
        <div class="othersCommentHeadportrait"><img src=${JSON.parse(reviewReturn).list[i].userInfo.avatar}  ></div>
        <div class="othersCommentNickname">${JSON.parse(reviewReturn).list[i].userInfo.userName}</div>
        <div class="othersCommentContent">${JSON.parse(reviewReturn).list[i].content}</div>
        <div class="othersCommentTime">${JSON.parse(reviewReturn).list[i].time}</div>
        <div class="othersMoreComment">-查看更多<span>${JSON.parse(reviewReturn).list[i].childrenReviews.length}</span>条回复-</div>
        <div class="othersCommentUpvote">
        <div>&#xe653;</div>
        <div>${JSON.parse(reviewReturn).list[i].goodNum}</div>
        </div></div>
        </div><div id='layer'></div>`
                                            }
                                            commentDetails.innerHTML = str1
                                            checkMoreReview.style.display = 'none'
                                                //如果评论的子评论数=0，则隐藏展示子评论的功能
                                            for (let i = 0; i < JSON.parse(reviewReturn).list.length; i++) {
                                                if (JSON.parse(reviewReturn).list[i].childrenReviews.length == 0) {
                                                    let othersMoreComment = document.querySelectorAll('.othersMoreComment')
                                                    othersMoreComment[i].style.display = 'none'
                                                }
                                            }
                                        })
                                    }
                                    // 让发评论旁边的小爱心即点赞数与上方的一致
                                    let reviewBottomUpvote = document.querySelector('#reviewBottomUpvote')
                                    console.log();
                                    reviewBottomUpvote.children[0].innerHTML = others_love_comment_collect.children[0].innerHTML
                                    reviewBottomUpvote.children[1].innerHTML = hotNumberText.children[1].innerHTML
                                        // 当上方的爱心被点击时
                                    others_love_comment_collect.children[0].addEventListener('click', function() {
                                            if (likingState == 1) {
                                                post('http://175.178.4.54:3007/like/cancelLikeArticle', `article_id=${photographArticle[i].articleId}`, function(data) {
                                                    console.log(data);
                                                    others_love_comment_collect.children[0].innerHTML = '&#xe653;'
                                                    likingState = 0
                                                    let hotNumberText = document.querySelector('#hotNumberText')
                                                    hotNumberText.children[1].innerHTML = parseInt(hotNumberText.children[1].innerHTML) - 1
                                                    reviewBottomUpvote.children[0].innerHTML = others_love_comment_collect.children[0].innerHTML
                                                    reviewBottomUpvote.children[1].innerHTML = hotNumberText.children[1].innerHTML
                                                })

                                            } else {
                                                post('http://175.178.4.54:3007/like/likeArticle', `article_id=${photographArticle[i].articleId}`, function(data) {
                                                    console.log(data);
                                                    others_love_comment_collect.children[0].innerHTML = '&#xe642;'
                                                    likingState = 1
                                                    console.log(hotNumberText);
                                                    hotNumberText.children[1].innerHTML = parseInt(hotNumberText.children[1].innerHTML) + 1
                                                    reviewBottomUpvote.children[0].innerHTML = others_love_comment_collect.children[0].innerHTML
                                                    reviewBottomUpvote.children[1].innerHTML = hotNumberText.children[1].innerHTML
                                                })
                                            }
                                        })
                                        //做下方的发评论
                                    let postReview = reviewBottom.querySelector('input')
                                        //当敲下键盘时，发送评论
                                    postReview.addEventListener('keydown', function(event) {
                                            if (event.keyCode == 13) {
                                                post('http://175.178.4.54:3007/review/submitReview', `content=${postReview.value}&articleId=${photographArticle[i].articleId}`, function() {
                                                    console.log(JSON.parse(data));
                                                    if (JSON.parse(data).status == 200) {
                                                        alert('发布成功')
                                                        postReview.value = ''
                                                    } else {
                                                        alert('未发布成功，请重试')
                                                    }
                                                })
                                                get('http://175.178.4.54:3007/review/getReviewsByArt', `articleId=${photographArticle[i].articleId}&page=1&size=2`, function() {
                                                    console.log(JSON.parse(data));
                                                })
                                            }
                                        })
                                        //仿照爱心点击做一个收藏点击事件
                                    others_love_comment_collect.children[2].addEventListener('click', function() {
                                            if (likingStateOfCollect == 1) {
                                                post('http://175.178.4.54:3007/star/cancelStarArticles', `article_id=${photographArticle[i].articleId}`, function(data) {
                                                    console.log(data);
                                                    others_love_comment_collect.children[2].innerHTML = '&#xe8ba;'
                                                    likingStateOfCollect = 0
                                                })

                                            } else {
                                                post('http://175.178.4.54:3007/star/starArticles', `article_id=${photographArticle[i].articleId}`, function(data) {
                                                    console.log(data);
                                                    others_love_comment_collect.children[2].innerHTML = '&#xe8c6;'
                                                    likingStateOfCollect = 1
                                                })
                                            }
                                        })
                                        //本来是复制上方的爱心点击代码，想到下面的爱心被点击与上方的爱心点击等效，于是将下一个爱心的点击事件与上方爱心点击事件连接起来
                                    reviewBottomUpvote.addEventListener('click', function() {
                                        others_love_comment_collect.children[0].click()
                                    })
                                    let othersMoreComment = document.querySelectorAll('.othersMoreComment')
                                    for (let i = 0; i < document.querySelectorAll('.commentBox').length; i++) {
                                        othersMoreComment[i].addEventListener('click', function() {
                                            othersMoreComment[i].style.display = 'none'
                                            let secondaryComments = document.querySelector('#secondaryComments')
                                            let othersInformationTitle = document.querySelector('#othersInformationTitle')
                                            let othersContentBody = document.querySelector('#othersContentBody')
                                            secondaryComments.style.display = 'block'
                                                //写二级评论
                                            let str2 = ''
                                            let layer = document.querySelector('#layer')
                                            for (let j = 0; j < JSON.parse(reviewReturn).list[i].childrenReviews.length; j++) {
                                                let p2 = new Promise((resolve, reject) => {
                                                    get('http://175.178.4.54:3007/userInfo/getUserInfo', `id=${JSON.parse(reviewReturn).list[i].childrenReviews[j].authorId}`, function(data) {
                                                        console.log(JSON.parse(data));
                                                        let userMessage = JSON.parse(data)
                                                        resolve(userMessage)
                                                    })
                                                })
                                                p2.then((userMessage) => {
                                                    for (let k = 0; k < JSON.parse(reviewReturn).list[i].childrenReviews.length; k++) {
                                                        str2 += `<div class="commentBox">
                                                            <div class="othersSecondaryCommentHeadportrait"><img src=${userMessage.data.avatar}  ></div>
                                                            <div class="othersCommentNickname">${userMessage.data.username}</div>
                                                            <div class="othersCommentContent">${JSON.parse(reviewReturn).list[i].childrenReviews[j].content}</div>
                                                            <div class="othersCommentTime">${JSON.parse(reviewReturn).list[i].childrenReviews[j].time}</div>
                                                            <div class="othersCommentUpvote">
                                                            <div>&#xe653;</div>
                                                            <div>${JSON.parse(reviewReturn).list[i].childrenReviews[j].goodNum}</div>
                                                            </div></div>  `
                                                    }
                                                    secondaryComments.innerHTML += str2
                                                    layer.style.display = 'block'
                                                    let putAway = document.querySelector('#putAway')
                                                    putAway.addEventListener('click', function() {
                                                        secondaryComments.style.display = 'none'
                                                        layer.style.display = 'none'
                                                        othersMoreComment[i].style.display = 'block'
                                                    })
                                                }, () => {})
                                            }
                                        })
                                    }
                                }, () => {})
                                //点进文章页以后，当前显示的页面消失，替换成文章页
                            details_title.style.display = 'block'
                            index.style.display = 'none'
                            footer.style.display = 'none'
                            let othersGoBack = document.querySelector('#othersGoBack')
                            othersGoBack.addEventListener('click', function() {
                                details_title.style.display = 'none'
                                index.style.display = 'block'
                                footer.style.display = 'flex'
                                    // let othersMoreComment = document.querySelectorAll('.othersMoreComment')
                                    // for (let i = 0; i < othersMoreComment.length; i++) {
                                    //     othersMoreComment[i].style.display = 'block'

                                // }
                            })
                        })


                    }, () => {})

                })
            }
        },
        () => {}
    )
}

getPhotographArticle()

function getFilmArticle() {
    let p = new Promise((resolve, reject) => {
        get('http://175.178.4.54:3007/article/getArticle', 'type=影视&page=1&size=10', function(data) {
            if (localStorage.getItem('filmArticleNumber')) {
                localStorage.removeItem('filmArticleNumber')
                localStorage.setItem('filmArticleNumber', JSON.parse(data).data.articleList.length)
            } else {
                localStorage.setItem('filmArticleNumber', JSON.parse(data).data.articleList.length)
            }
            filmArticle = JSON.parse(data).data.articleList
            console.log(filmArticle);
            resolve(filmArticle)
        })
    })
    p.then(
        // 字符串拼接创建多个盒子
        (filmArticle) => {
            let str = ''
            for (let i = 0; i < filmArticle.length; i++) {
                str += `<div class="item"><img data-src=${filmArticle[i].avatar}>
    <div class="text"><span data-text=${filmArticle[i].title}></span><span class="more">&#xe600;</span></div>
    <div class="tag"><div data-text=${filmArticle[i].label[0]}></div></div>
    <div class="bottomRow">
    <div class="headPortrait"><img  data-src=${filmArticle[i].cover}></div>
    <div class="nickname" data-text=${filmArticle[i].username}></div>
    <div class="upvote"> <div class="heart">&#xe653;</div> <div class="number" data-number=${filmArticle[i].fanNum}></div>
    </div></div></div>`
            }
            container4.innerHTML = str
            itemNum4 = container4.children
            itemNum4Arr = [...itemNum4]
                // 观察者模式：当看见元素的时候，让他加载：把前面预存在data-的数据给拿出来
            const callback = entries => {
                for (let i = 0; i < entries.length; i++) {
                    if (entries[i].isIntersecting) {
                        let item = entries[i].target
                        let data_src0 = item.children[0].getAttribute('data-src')
                        item.children[0].setAttribute('src', data_src0)
                        let data_text0 = item.children[1].firstChild.getAttribute('data-text')
                        item.children[1].firstChild.innerHTML = data_text0
                        let data_text1 = item.children[2].firstElementChild.getAttribute('data-text')
                        item.children[2].firstElementChild.innerHTML = '#' + data_text1
                        let data_src1 = item.children[3].firstElementChild.firstElementChild.getAttribute('data-src')
                        item.children[3].firstElementChild.firstElementChild.setAttribute('src', data_src1)
                        let data_text2 = item.children[3].children[1].getAttribute('data-text')
                        item.children[3].children[1].innerHTML = data_text2
                        let data_number = item.children[3].children[2].children[1].getAttribute('data-number')
                        item.children[3].children[2].children[1].innerHTML = data_number
                        observer.unobserve(item)
                        console.log('触发');
                        subheadings.children[5].addEventListener('click', function() {
                            // 这个本来是同步的，加载图片是异步的，那么只需让排序也放进堆内执行，就可以实现瀑布流，于是给一个很短的定时器来实现
                            setTimeout(function() {
                                let oItem = container4.children
                                let clientwidth = document.documentElement.clientWidth
                                let itemWidth = oItem[0].offsetWidth
                                let num = Math.floor(clientwidth / itemWidth)
                                container4.style.width = num * itemWidth + 1 + 'px'
                                let hrr = []
                                for (let i = 0; i < container4.children.length; i++) {
                                    if (i < num) {
                                        hrr.push(container4.children[i].offsetHeight)
                                        console.log(hrr);
                                    } else {
                                        let minHeight = Math.min(...hrr)
                                        let index = fInArray(minHeight, hrr)
                                        container4.children[i].style.position = 'absolute'
                                        container4.children[i].style.top = minHeight + 'px'
                                        container4.children[i].style.left = index * itemWidth + 'px'
                                        hrr[index] += container4.children[i].offsetHeight
                                    }
                                }
                            }, 100)
                        })
                    }
                }
            }
            const observer = new IntersectionObserver(callback)
            itemNum4Arr.forEach(item => {
                observer.observe(item)
            })

            function fInArray(min, hrr) {
                for (let i = 0; i < hrr.length; i++) {
                    if (hrr[i] == min) {
                        return i
                    }
                }
            }
            //点击盒子让详细内容加载  这里移植性相当的好，只需要改几个把从主页获取的信息的对象换一下就行了
            for (let i = 0; i < container4.children.length; i++) {
                //在获取文章详细信息之前，先检测一下文章有没有被我喜欢
                container4.children[i].addEventListener('click', function() {
                    // linkState初始值是0，如果发送取消喜欢请求后成功取消的话，那么说明已经喜欢过了，让linkState等于1，并发送一次喜欢请求恢复原样
                    //其实可以在这里把喜欢，收藏，关注请求一起发，然后用promise.all一起接收的，可以简化一下逻辑
                    let likingState = 0
                    let p0 = new Promise((resolve, reject) => {
                        console.log(filmArticle[i]);
                        post('http://175.178.4.54:3007/like/cancelLikeArticle', `article_id=${filmArticle[i].articleId}`, function(data) {
                            console.log(data);
                            console.log(JSON.parse(data));
                            if (JSON.parse(data).message != '您还没有喜欢过该文章') {
                                post('http://175.178.4.54:3007/like/likeArticle', `article_id=${filmArticle[i].articleId}`, function(data) {
                                    console.log(data);
                                })
                                likingState = 1
                            } else {
                                likingState = 0
                            }
                            resolve(likingState)
                        })
                    })
                    let p1 = new Promise((resolve, reject) => {
                        post('http://175.178.4.54:3007/star/cancelStarArticles', `article_id=${filmArticle[i].articleId}`, function(data) {
                            console.log(JSON.parse(data));
                            if (JSON.parse(data).message != '您还没有收藏过该文章') {
                                post('http://175.178.4.54:3007/star/starArticles', `article_id=${filmArticle[i].articleId}`, function(data) {
                                    console.log(data);
                                })
                                likingStateOfCollect = 1
                            } else {
                                likingStateOfCollect = 0
                            }
                            resolve(likingStateOfCollect)
                        })
                    })
                    let pAll = Promise.all([p0, p1])
                    pAll.then((res) => {
                        get('http://175.178.4.54:3007/article/getDetails', `articleId=${filmArticle[i].articleId}`, function(data) {
                            console.log(JSON.parse(data));
                            let details_title = document.querySelector('#details_title')
                            console.log(details_title);
                            //将除了底下的评论部分的内容放进页面中
                            let str = `
            <div id="othersInformation">
            <div id='othersInformationTitle'>
            <div id="othersGoBack">&#xe8ef;</div>
                <div id="othersHeadPortrait"><img src=${JSON.parse(data).data.avatar}  ></div>
                <div id="othersName_time">
                    <div id="othersName">${JSON.parse(data).data.authorName}</div>
                    <div id="othersTime">${JSON.parse(data).data.time}</div>
                </div>
                <div id="othersFocus">关注</div>
                </div>
                <div id='othersContentBody'>
                <div id="othersImg"><img src=${JSON.parse(data).data.img[0]}  ></div>
                <div id="othersContent">${JSON.parse(data).data.content}</div>
                <div id="othersTag"></div>
                <div id="others_love_comment_collect"><span>&#xe653;</span><span id="commentIcon">&#xe8b4;</span><span id="collectIcon">&#xe8ba;</span></div>
                <div id="fanNum_commentNum">
                    <i id="hotNumberText"><span>热度</span> <span>${JSON.parse(data).data.fanNum}</span></i>
                    <i id="commentNumberText"><span>评论</span> <span>${JSON.parse(data).data.reviewNum}</span></i>
                </div>
                </div>
                <div id="comment">
        <div id="hotComment">热门评论</div>
        <div id="commentDetails"></div>
        <div id="reviewBottom"><input type="text" placeholder="我要发评论">
            <div id='reviewBottomUpvote'>
                <div>&#xe653;</div>
                <div>${JSON.parse(data).data.fanNum}</div>
            </div>
            <div id='reviewBottomReview'>
                <div>&#xe8b4;</div>
                <div>${JSON.parse(data).data.reviewNum}</div>
            </div>
        </div>
        <div id='secondaryComments'><span id='putAway'>&#xe601;</span></div>
        <div id="checkMoreReview">查看更多评论</div>
    </div>
            </div>`
                            details_title.innerHTML = str
                                //文章中的各种数据
                            let hotNumberText = document.querySelector('#hotNumberText')
                            let img = document.querySelector('#othersImg').children[0]
                                //当图片加载不出来的时候隐藏
                            img.addEventListener('error', function() {
                                this.style.display = 'none'
                            })
                            let othersTag = document.querySelector('#othersTag')
                                // 给文章添加标签
                            for (let i = 0; i < JSON.parse(data).data.label.length; i++) {
                                othersTag.innerHTML += `<i>${JSON.parse(data).data.label[i]}</i>`
                            }
                            let others_love_comment_collect = document.querySelector('#others_love_comment_collect')
                            if (likingState == 1) {
                                others_love_comment_collect.children[0].innerHTML = '&#xe642;'
                            } else {
                                others_love_comment_collect.children[0].innerHTML = '&#xe653;'
                            }
                            if (likingStateOfCollect == 1) {
                                others_love_comment_collect.children[2].innerHTML = '&#xe8c6;'
                            } else {
                                others_love_comment_collect.children[2].innerHTML = '&#xe8ba;'
                            }
                            // if (likingStateOfFocus == 1) {
                            //     let othersFocus = document.querySelector('#othersFocus')
                            //     othersFocus.innerHTML = '已关注'
                            //     othersFocus.className = 'othersFocus_focused'
                            // } else {
                            //     othersFocus.innerHTML = '关注'
                            //     othersFocus.className = ''
                            // }
                            // 加载具体的评论
                            let p1 = new Promise((resolve, reject) => {
                                get('http://175.178.4.54:3007/review/getReviewsByArt', `articleId=${filmArticle[i].articleId}&page=1&size=20`, function(data) {
                                    let reviewReturn = data
                                    console.log(JSON.parse(reviewReturn));
                                    resolve(reviewReturn)
                                })
                            })
                            p1.then((reviewReturn) => {
                                    // 在热门评论处添加评论
                                    let commentDetails = document.querySelector('#commentDetails')
                                    let checkMoreReview = document.querySelector('#checkMoreReview')
                                    if (JSON.parse(reviewReturn).list.length <= 2 && JSON.parse(reviewReturn).list.length != 0) {
                                        let str1 = ''
                                        for (let i = 0; i < JSON.parse(reviewReturn).list.length; i++) {
                                            str1 += `<div class="commentBox">
<div class="othersCommentHeadportrait"><img src=${JSON.parse(reviewReturn).list[i].userInfo.avatar}  ></div>
<div class="othersCommentNickname">${JSON.parse(reviewReturn).list[i].userInfo.userName}</div>
<div class="othersCommentContent">${JSON.parse(reviewReturn).list[i].content}</div>
<div class="othersCommentTime">${JSON.parse(reviewReturn).list[i].time}</div>
<div class="othersMoreComment">-查看更多<span>${JSON.parse(reviewReturn).list[i].childrenReviews.length}</span>条回复-</div>
<div class="othersCommentUpvote">
<div>&#xe653;</div>
<div>${JSON.parse(reviewReturn).list[i].goodNum}</div>
</div>
</div>
</div><div id='layer'></div>`
                                        }
                                        commentDetails.innerHTML = str1
                                            //如果评论数小于等于2，则隐藏展示更多评论的功能
                                        for (let i = 0; i < JSON.parse(reviewReturn).list.length; i++) {
                                            if (JSON.parse(reviewReturn).list[i].childrenReviews.length == 0 && JSON.parse(reviewReturn).list.length != 0) {
                                                let othersMoreComment = document.querySelectorAll('.othersMoreComment')
                                                othersMoreComment[i].style.display = 'none'
                                            }
                                        }
                                        //当加载更多评论被点击以后，加载更多评论，当二级评论数为0的话，隐藏展开评论
                                        checkMoreReview.style.display = 'none'
                                    } else if (JSON.parse(reviewReturn).list.length == 0) {
                                        checkMoreReview.style.display = 'none'
                                    } else {
                                        // 当评论数大于2的情况，加载两项评论，如果二级评论数为0的话，隐藏展开评论
                                        //先加载两项，等点击加载更多以后再显示全部
                                        let str1 = ''
                                        for (let i = 0; i < 2; i++) {
                                            str1 += `<div class="commentBox">
    <div class="othersCommentHeadportrait"><img src=${JSON.parse(reviewReturn).list[i].userInfo.avatar}  ></div>
    <div class="othersCommentNickname">${JSON.parse(reviewReturn).list[i].userInfo.userName}</div>
    <div class="othersCommentContent">${JSON.parse(reviewReturn).list[i].content}</div>
    <div class="othersCommentTime">${JSON.parse(reviewReturn).list[i].time}</div>
    <div class="othersMoreComment">-查看更多<span>${JSON.parse(reviewReturn).list[i].childrenReviews.length}</span>条回复-</div>
    <div class="othersCommentUpvote">
    <div>&#xe653;</div>
    <div>${JSON.parse(reviewReturn).list[i].goodNum}</div>
    </div>
    </div>
    </div><div id='layer'></div>`
                                        }
                                        commentDetails.innerHTML = str1
                                            //如果评论的子评论数=0，则隐藏展示子评论的功能
                                        for (let i = 0; i < 2; i++) {
                                            if (JSON.parse(reviewReturn).list[i].childrenReviews.length == 0) {
                                                let othersMoreComment = document.querySelectorAll('.othersMoreComment')
                                                othersMoreComment[i].style.display = 'none'
                                            }
                                        }
                                        //当加载更多评论被点击以后，加载更多评论，当二级评论数为0的话，隐藏展开评论
                                        checkMoreReview.addEventListener('click', function() {
                                            let str1 = ``
                                            for (let i = 0; i < JSON.parse(reviewReturn).list.length; i++) {
                                                str1 += `<div class="commentBox">
        <div class="othersCommentHeadportrait"><img src=${JSON.parse(reviewReturn).list[i].userInfo.avatar}  ></div>
        <div class="othersCommentNickname">${JSON.parse(reviewReturn).list[i].userInfo.userName}</div>
        <div class="othersCommentContent">${JSON.parse(reviewReturn).list[i].content}</div>
        <div class="othersCommentTime">${JSON.parse(reviewReturn).list[i].time}</div>
        <div class="othersMoreComment">-查看更多<span>${JSON.parse(reviewReturn).list[i].childrenReviews.length}</span>条回复-</div>
        <div class="othersCommentUpvote">
        <div>&#xe653;</div>
        <div>${JSON.parse(reviewReturn).list[i].goodNum}</div>
        </div></div>
        </div><div id='layer'></div>`
                                            }
                                            commentDetails.innerHTML = str1
                                            checkMoreReview.style.display = 'none'
                                                //如果评论的子评论数=0，则隐藏展示子评论的功能
                                            for (let i = 0; i < JSON.parse(reviewReturn).list.length; i++) {
                                                if (JSON.parse(reviewReturn).list[i].childrenReviews.length == 0) {
                                                    let othersMoreComment = document.querySelectorAll('.othersMoreComment')
                                                    othersMoreComment[i].style.display = 'none'
                                                }
                                            }
                                        })
                                    }

                                    // 让发评论旁边的小爱心即点赞数与上方的一致
                                    let reviewBottomUpvote = document.querySelector('#reviewBottomUpvote')
                                    reviewBottomUpvote.children[0].innerHTML = others_love_comment_collect.children[0].innerHTML
                                    reviewBottomUpvote.children[1].innerHTML = hotNumberText.children[1].innerHTML
                                        // 当上方的爱心被点击时
                                    others_love_comment_collect.children[0].addEventListener('click', function() {
                                            if (likingState == 1) {
                                                post('http://175.178.4.54:3007/like/cancelLikeArticle', `article_id=${filmArticle[i].articleId}`, function(data) {
                                                    console.log(data);
                                                    others_love_comment_collect.children[0].innerHTML = '&#xe653;'
                                                    likingState = 0
                                                    let hotNumberText = document.querySelector('#hotNumberText')
                                                    hotNumberText.children[1].innerHTML = parseInt(hotNumberText.children[1].innerHTML) - 1
                                                    reviewBottomUpvote.children[0].innerHTML = others_love_comment_collect.children[0].innerHTML
                                                    reviewBottomUpvote.children[1].innerHTML = hotNumberText.children[1].innerHTML
                                                })

                                            } else {
                                                post('http://175.178.4.54:3007/like/likeArticle', `article_id=${filmArticle[i].articleId}`, function(data) {
                                                    console.log(data);
                                                    others_love_comment_collect.children[0].innerHTML = '&#xe642;'
                                                    likingState = 1
                                                    console.log(hotNumberText);
                                                    hotNumberText.children[1].innerHTML = parseInt(hotNumberText.children[1].innerHTML) + 1
                                                    reviewBottomUpvote.children[0].innerHTML = others_love_comment_collect.children[0].innerHTML
                                                    reviewBottomUpvote.children[1].innerHTML = hotNumberText.children[1].innerHTML
                                                })
                                            }
                                        })
                                        //做下方的发评论
                                    let postReview = reviewBottom.querySelector('input')
                                        //当敲下键盘时，发送评论
                                    postReview.addEventListener('keydown', function(event) {
                                            if (event.keyCode == 13) {
                                                post('http://175.178.4.54:3007/review/submitReview', `content=${postReview.value}&articleId=${filmArticle[i].articleId}`, function() {
                                                    console.log(JSON.parse(data));
                                                    if (JSON.parse(data).status == 200) {
                                                        alert('发布成功')
                                                        postReview.value = ''
                                                    } else {
                                                        alert('未发布成功，请重试')
                                                    }
                                                })
                                                get('http://175.178.4.54:3007/review/getReviewsByArt', `articleId=${filmArticle[i].articleId}&page=1&size=2`, function() {
                                                    console.log(JSON.parse(data));
                                                })
                                            }
                                        })
                                        //仿照爱心点击做一个收藏点击事件
                                    others_love_comment_collect.children[2].addEventListener('click', function() {
                                            if (likingStateOfCollect == 1) {
                                                post('http://175.178.4.54:3007/star/cancelStarArticles', `article_id=${filmArticle[i].articleId}`, function(data) {
                                                    console.log(data);
                                                    others_love_comment_collect.children[2].innerHTML = '&#xe8ba;'
                                                    likingStateOfCollect = 0
                                                })

                                            } else {
                                                post('http://175.178.4.54:3007/star/starArticles', `article_id=${filmArticle[i].articleId}`, function(data) {
                                                    console.log(data);
                                                    others_love_comment_collect.children[2].innerHTML = '&#xe8c6;'
                                                    likingStateOfCollect = 1
                                                })
                                            }
                                        })
                                        //本来是复制上方的爱心点击代码，想到下面的爱心被点击与上方的爱心点击等效，于是将下一个爱心的点击事件与上方爱心点击事件连接起来
                                    reviewBottomUpvote.addEventListener('click', function() {
                                        others_love_comment_collect.children[0].click()
                                    })
                                    let othersMoreComment = document.querySelectorAll('.othersMoreComment')
                                    for (let i = 0; i < document.querySelectorAll('.commentBox').length; i++) {
                                        othersMoreComment[i].addEventListener('click', function() {
                                            othersMoreComment[i].style.display = 'none'
                                            let secondaryComments = document.querySelector('#secondaryComments')
                                            let othersInformationTitle = document.querySelector('#othersInformationTitle')
                                            let othersContentBody = document.querySelector('#othersContentBody')
                                            secondaryComments.style.display = 'block'
                                                //写二级评论
                                            let str2 = ''
                                            let layer = document.querySelector('#layer')
                                            for (let j = 0; j < JSON.parse(reviewReturn).list[i].childrenReviews.length; j++) {
                                                let p2 = new Promise((resolve, reject) => {
                                                    get('http://175.178.4.54:3007/userInfo/getUserInfo', `id=${JSON.parse(reviewReturn).list[i].childrenReviews[j].authorId}`, function(data) {
                                                        console.log(JSON.parse(data));
                                                        let userMessage = JSON.parse(data)
                                                        resolve(userMessage)
                                                    })
                                                })
                                                p2.then((userMessage) => {
                                                    for (let k = 0; k < JSON.parse(reviewReturn).list[i].childrenReviews.length; k++) {
                                                        str2 += `<div class="commentBox">
                                                            <div class="othersSecondaryCommentHeadportrait"><img src=${userMessage.data.avatar}  ></div>
                                                            <div class="othersCommentNickname">${userMessage.data.username}</div>
                                                            <div class="othersCommentContent">${JSON.parse(reviewReturn).list[i].childrenReviews[j].content}</div>
                                                            <div class="othersCommentTime">${JSON.parse(reviewReturn).list[i].childrenReviews[j].time}</div>
                                                            <div class="othersCommentUpvote">
                                                            <div>&#xe653;</div>
                                                            <div>${JSON.parse(reviewReturn).list[i].childrenReviews[j].goodNum}</div>
                                                            </div></div>`
                                                    }
                                                    secondaryComments.innerHTML += str2
                                                    layer.style.display = 'block'
                                                    let putAway = document.querySelector('#putAway')
                                                    putAway.addEventListener('click', function() {
                                                        secondaryComments.style.display = 'none'
                                                        layer.style.display = 'none'
                                                        othersMoreComment[i].style.display = 'block'
                                                    })
                                                }, () => {})

                                            }

                                        })
                                    }
                                }, () => {})
                                //点进文章页以后，当前显示的页面消失，替换成文章页
                            details_title.style.display = 'block'
                            index.style.display = 'none'
                            footer.style.display = 'none'
                            let othersGoBack = document.querySelector('#othersGoBack')
                            othersGoBack.addEventListener('click', function() {
                                details_title.style.display = 'none'
                                index.style.display = 'block'
                                footer.style.display = 'flex'
                            })
                        })
                    }, () => {})
                })
            }
        },
        () => {}
    )
}

getFilmArticle()

function getEntertainmentArticle() {
    // 获取首页文章   后面几个的内容都好相似，后面有空的话可以直接用一个函数来替换掉这里的一大堆内容
    let p = new Promise((resolve, reject) => {
        get('http://175.178.4.54:3007/article/getArticle', 'type=娱乐&page=1&size=100', function(data) {
            if (localStorage.getItem('entertainmentArticleNumber')) {
                localStorage.removeItem('entertainmentArticleNumber')
                localStorage.setItem('entertainmentArticleNumber', JSON.parse(data).data.articleList.length)
            } else {
                localStorage.setItem('entertainmentArticleNumber', JSON.parse(data).data.articleList.length)
            }
            entertainmentArticle = JSON.parse(data).data.articleList
            console.log(entertainmentArticle);
            resolve(entertainmentArticle)
        })
    })
    p.then(
        // 字符串拼接创建多个盒子
        (entertainmentArticle) => {
            let str = ''
            for (let i = 0; i < entertainmentArticle.length; i++) {
                str += `<div class="item"><img data-src=${entertainmentArticle[i].avatar}>
    <div class="text"><span data-text=${entertainmentArticle[i].title}></span><span class="more">&#xe600;</span></div>
    <div class="tag"><div data-text=${entertainmentArticle[i].label[0]}></div></div>
    <div class="bottomRow">
    <div class="headPortrait"><img  data-src=${entertainmentArticle[i].cover}></div>
    <div class="nickname" data-text=${entertainmentArticle[i].username}></div>
    <div class="upvote"> <div class="heart">&#xe653;</div> <div class="number" data-number=${entertainmentArticle[i].fanNum}></div>
    </div>
    </div>
    </div>`
            }
            console.log(container5);
            container5.innerHTML = str
            itemNum5 = container5.children
            itemNum5Arr = [...itemNum5]
                // 当看见元素的时候，让他加载（观察者）
            const callback = entries => {
                for (let i = 0; i < entries.length; i++) {
                    if (entries[i].isIntersecting) {
                        let item = entries[i].target
                        let data_src0 = item.children[0].getAttribute('data-src')
                        item.children[0].setAttribute('src', data_src0)
                        let data_text0 = item.children[1].firstChild.getAttribute('data-text')
                        item.children[1].firstChild.innerHTML = data_text0
                        let data_text1 = item.children[2].firstElementChild.getAttribute('data-text')
                        item.children[2].firstElementChild.innerHTML = '#' + data_text1
                        let data_src1 = item.children[3].firstElementChild.firstElementChild.getAttribute('data-src')
                        item.children[3].firstElementChild.firstElementChild.setAttribute('src', data_src1)
                        let data_text2 = item.children[3].children[1].getAttribute('data-text')
                        item.children[3].children[1].innerHTML = data_text2
                        let data_number = item.children[3].children[2].children[1].getAttribute('data-number')
                        item.children[3].children[2].children[1].innerHTML = data_number
                        observer.unobserve(item)
                        console.log('触发');
                        subheadings.children[6].addEventListener('click', function() {
                            setTimeout(function() {

                                let oItem = container5.children
                                let clientwidth = document.documentElement.clientWidth
                                let itemWidth = oItem[0].offsetWidth
                                let num = Math.floor(clientwidth / itemWidth)
                                container5.style.width = num * itemWidth + 1 + 'px'
                                let hrr = []
                                for (let i = 0; i < container5.children.length; i++) {
                                    if (i < num) {
                                        hrr.push(container5.children[i].offsetHeight)
                                        console.log(hrr);
                                    } else {
                                        let minHeight = Math.min(...hrr)
                                        let index = fInArray(minHeight, hrr)
                                        container5.children[i].style.position = 'absolute'
                                        container5.children[i].style.top = minHeight + 'px'
                                        container5.children[i].style.left = index * itemWidth + 'px'
                                        hrr[index] += container5.children[i].offsetHeight
                                    }
                                }
                            }, 100)
                        })
                    }
                }
            }
            const observer = new IntersectionObserver(callback)
            itemNum5Arr.forEach(item => {
                observer.observe(item)
            })

            function fInArray(min, hrr) {
                for (let i = 0; i < hrr.length; i++) {
                    if (hrr[i] == min) {
                        return i
                    }
                }
            }
            for (let i = 0; i < container5.children.length; i++) {
                //在获取文章详细信息之前，先检测一下文章有没有被我喜欢
                container5.children[i].addEventListener('click', function() {
                    // linkState初始值是0，如果发送取消喜欢请求后成功取消的话，那么说明已经喜欢过了，让linkState等于1，并发送一次喜欢请求恢复原样
                    //其实可以在这里把喜欢，收藏，关注请求一起发，然后用promise.all一起接收的，可以简化一下逻辑

                    let likingState = 0
                    let p0 = new Promise((resolve, reject) => {
                        console.log(entertainmentArticle[i]);
                        post('http://175.178.4.54:3007/like/cancelLikeArticle', `article_id=${entertainmentArticle[i].articleId}`, function(data) {
                            console.log(data);
                            console.log(JSON.parse(data));
                            if (JSON.parse(data).message != '您还没有喜欢过该文章') {
                                post('http://175.178.4.54:3007/like/likeArticle', `article_id=${entertainmentArticle[i].articleId}`, function(data) {
                                    console.log(data);
                                })
                                likingState = 1
                            } else {
                                likingState = 0
                            }
                            resolve(likingState)
                        })
                    })
                    let p1 = new Promise((resolve, reject) => {
                        post('http://175.178.4.54:3007/star/cancelStarArticles', `article_id=${entertainmentArticle[i].articleId}`, function(data) {
                            console.log(JSON.parse(data));
                            if (JSON.parse(data).message != '您还没有收藏过该文章') {
                                post('http://175.178.4.54:3007/star/starArticles', `article_id=${entertainmentArticle[i].articleId}`, function(data) {
                                    console.log(data);
                                })
                                likingStateOfCollect = 1
                            } else {
                                likingStateOfCollect = 0
                            }
                            resolve(likingStateOfCollect)
                        })
                    })
                    let pAll = Promise.all([p0, p1])
                    pAll.then((res) => {
                        [likingState, likingStateOfCollect] = res
                        get('http://175.178.4.54:3007/article/getDetails', `articleId=${entertainmentArticle[i].articleId}`, function(data) {
                            console.log(JSON.parse(data));
                            let details_title = document.querySelector('#details_title')
                            console.log(details_title);
                            //将除了底下的评论部分的内容放进页面中
                            let str = `
            <div id="othersInformation">
            <div id='othersInformationTitle'>
            <div id="othersGoBack">&#xe8ef;</div>
                <div id="othersHeadPortrait"><img src=${JSON.parse(data).data.avatar} ></div>
                <div id="othersName_time">
                    <div id="othersName">${JSON.parse(data).data.authorName}</div>
                    <div id="othersTime">${JSON.parse(data).data.time}</div>
                </div>
                <div id="othersFocus">关注</div>
                </div>
                <div id='othersContentBody'>
                <div id="othersImg"><img src=${JSON.parse(data).data.img[0]} ></div>
                <div id="othersContent">${JSON.parse(data).data.content}</div>
                <div id="othersTag"></div>
                <div id="others_love_comment_collect"><span>&#xe653;</span><span id="commentIcon">&#xe8b4;</span><span id="collectIcon">&#xe8ba;</span></div>
                <div id="fanNum_commentNum">
                    <i id="hotNumberText"><span>热度</span> <span>${JSON.parse(data).data.fanNum}</span></i>
                    <i id="commentNumberText"><span>评论</span> <span>${JSON.parse(data).data.reviewNum}</span></i>
                </div>
                </div>
                <div id="comment">
        <div id="hotComment">热门评论</div>
        <div id="commentDetails"></div>
        <div id="reviewBottom"><input type="text" placeholder="我要发评论">
            <div id='reviewBottomUpvote'>
                <div>&#xe653;</div>
                <div>${JSON.parse(data).data.fanNum}</div>
            </div>
            <div id='reviewBottomReview'>
                <div>&#xe8b4;</div>
                <div>${JSON.parse(data).data.reviewNum}</div>
            </div>
        </div>
        <div id='secondaryComments'><span id='putAway'>&#xe601;</span></div>
        <div id="checkMoreReview">查看更多评论</div>
    </div>
            </div>`
                            details_title.innerHTML = str
                                //文章中的各种数据
                            let hotNumberText = document.querySelector('#hotNumberText')
                            let img = document.querySelector('#othersImg').children[0]
                                //当图片加载不出来的时候隐藏
                            img.addEventListener('error', function() {
                                this.style.display = 'none'
                            })
                            let othersTag = document.querySelector('#othersTag')
                            for (let i = 0; i < JSON.parse(data).data.label.length; i++) {
                                othersTag.innerHTML += `<i>${JSON.parse(data).data.label[i]}</i>`
                            }
                            let others_love_comment_collect = document.querySelector('#others_love_comment_collect')
                            if (likingState == 1) {
                                others_love_comment_collect.children[0].innerHTML = '&#xe642;'
                            } else {
                                others_love_comment_collect.children[0].innerHTML = '&#xe653;'
                            }
                            if (likingStateOfCollect == 1) {
                                others_love_comment_collect.children[2].innerHTML = '&#xe8c6;'
                            } else {
                                others_love_comment_collect.children[2].innerHTML = '&#xe8ba;'
                            }
                            // if (likingStateOfFocus == 1) {
                            //     let othersFocus = document.querySelector('#othersFocus')
                            //     othersFocus.innerHTML = '已关注'
                            //     othersFocus.className = 'othersFocus_focused'
                            // } else {
                            //     othersFocus.innerHTML = '关注'
                            //     othersFocus.className = ''
                            // }
                            // 加载具体的评论
                            let p1 = new Promise((resolve, reject) => {
                                get('http://175.178.4.54:3007/review/getReviewsByArt', `articleId=${entertainmentArticle[i].articleId}&page=1&size=2`, function(data) {
                                    let reviewReturn = data
                                    console.log(JSON.parse(reviewReturn));
                                    resolve(reviewReturn)
                                })
                            })
                            p1.then((reviewReturn) => {
                                    // 在热门评论处添加评论
                                    let commentDetails = document.querySelector('#commentDetails')
                                    let checkMoreReview = document.querySelector('#checkMoreReview')
                                    if (JSON.parse(reviewReturn).list.length <= 2 && JSON.parse(reviewReturn).list.length != 0) {
                                        let str1 = ''
                                        for (let i = 0; i < JSON.parse(reviewReturn).list.length; i++) {
                                            str1 += `<div class="commentBox">
<div class="othersCommentHeadportrait"><img src=${JSON.parse(reviewReturn).list[i].userInfo.avatar} ></div>
<div class="othersCommentNickname">${JSON.parse(reviewReturn).list[i].userInfo.userName}</div>
<div class="othersCommentContent">${JSON.parse(reviewReturn).list[i].content}</div>
<div class="othersCommentTime">${JSON.parse(reviewReturn).list[i].time}</div>
<div class="othersMoreComment">-查看更多<span>${JSON.parse(reviewReturn).list[i].childrenReviews.length}</span>条回复-</div>
<div class="othersCommentUpvote">
<div>&#xe653;</div>
<div>${JSON.parse(reviewReturn).list[i].goodNum}</div>
</div>
</div>
</div><div id='layer'></div>`
                                        }

                                        //此处移植过去后可先判断没有评论的情况，顺便把展开更多评论也改一下
                                        commentDetails.innerHTML = str1
                                            //如果评论数小于等于2，则隐藏展示更多评论的功能
                                        for (let i = 0; i < 2; i++) {
                                            if (JSON.parse(reviewReturn).list[i].childrenReviews.length == 0) {
                                                let othersMoreComment = document.querySelectorAll('.othersMoreComment')
                                                othersMoreComment[i].style.display = 'none'
                                            }
                                        }
                                        //当加载更多评论被点击以后，加载更多评论，当二级评论数为0的话，隐藏展开评论
                                        checkMoreReview.style.display = 'none'
                                    } else if (JSON.parse(reviewReturn).list.length == 0) {
                                        checkMoreReview.style.display = 'none'
                                    } else {
                                        // 当评论数大于2的情况，加载两项评论，如果二级评论数为0的话，隐藏展开评论
                                        //先加载两项，等点击加载更多以后再显示全部
                                        let str1 = ''
                                        for (let i = 0; i < 2; i++) {
                                            str1 += `<div class="commentBox">
    <div class="othersCommentHeadportrait"><img src=${JSON.parse(reviewReturn).list[i].userInfo.avatar}  ></div>
    <div class="othersCommentNickname">${JSON.parse(reviewReturn).list[i].userInfo.userName}</div>
    <div class="othersCommentContent">${JSON.parse(reviewReturn).list[i].content}</div>
    <div class="othersCommentTime">${JSON.parse(reviewReturn).list[i].time}</div>
    <div class="othersMoreComment">-查看更多<span>${JSON.parse(reviewReturn).list[i].childrenReviews.length}</span>条回复-</div>
    <div class="othersCommentUpvote">
    <div>&#xe653;</div>
    <div>${JSON.parse(reviewReturn).list[i].goodNum}</div>
    </div>
    </div>
    </div><div id='layer'></div>`
                                        }
                                        commentDetails.innerHTML = str1
                                            //如果评论的子评论数=0，则隐藏展示子评论的功能
                                        for (let i = 0; i < 2; i++) {
                                            if (JSON.parse(reviewReturn).list[i].childrenReviews.length == 0) {
                                                let othersMoreComment = document.querySelectorAll('.othersMoreComment')
                                                othersMoreComment[i].style.display = 'none'
                                            }
                                        }
                                        //当加载更多评论被点击以后，加载更多评论，当二级评论数为0的话，隐藏展开评论
                                        checkMoreReview.addEventListener('click', function() {
                                            let str1 = ``
                                            for (let i = 0; i < JSON.parse(reviewReturn).list.length; i++) {
                                                str1 += `<div class="commentBox">
        <div class="othersCommentHeadportrait"><img src=${JSON.parse(reviewReturn).list[i].userInfo.avatar}  ></div>
        <div class="othersCommentNickname">${JSON.parse(reviewReturn).list[i].userInfo.userName}</div>
        <div class="othersCommentContent">${JSON.parse(reviewReturn).list[i].content}</div>
        <div class="othersCommentTime">${JSON.parse(reviewReturn).list[i].time}</div>
        <div class="othersMoreComment">-查看更多<span>${JSON.parse(reviewReturn).list[i].childrenReviews.length}</span>条回复-</div>
        <div class="othersCommentUpvote">
        <div>&#xe653;</div>
        <div>${JSON.parse(reviewReturn).list[i].goodNum}</div>
        </div></div>
        </div><div id='layer'></div>`
                                            }
                                            commentDetails.innerHTML = str1
                                            checkMoreReview.style.display = 'none'
                                                //如果评论的子评论数=0，则隐藏展示子评论的功能
                                            for (let i = 0; i < JSON.parse(reviewReturn).list.length; i++) {
                                                if (JSON.parse(reviewReturn).list[i].childrenReviews.length == 0) {
                                                    let othersMoreComment = document.querySelectorAll('.othersMoreComment')
                                                    othersMoreComment[i].style.display = 'none'
                                                }
                                            }
                                        })
                                    }
                                    // 让发评论旁边的小爱心即点赞数与上方的一致
                                    let reviewBottomUpvote = document.querySelector('#reviewBottomUpvote')
                                    reviewBottomUpvote.children[0].innerHTML = others_love_comment_collect.children[0].innerHTML
                                    reviewBottomUpvote.children[1].innerHTML = hotNumberText.children[1].innerHTML
                                        // 当上方的爱心被点击时
                                    others_love_comment_collect.children[0].addEventListener('click', function() {
                                            if (likingState == 1) {
                                                post('http://175.178.4.54:3007/like/cancelLikeArticle', `article_id=${entertainmentArticle[i].articleId}`, function(data) {
                                                    console.log(data);
                                                    others_love_comment_collect.children[0].innerHTML = '&#xe653;'
                                                    likingState = 0
                                                    let hotNumberText = document.querySelector('#hotNumberText')
                                                    hotNumberText.children[1].innerHTML = parseInt(hotNumberText.children[1].innerHTML) - 1
                                                    reviewBottomUpvote.children[0].innerHTML = others_love_comment_collect.children[0].innerHTML
                                                    reviewBottomUpvote.children[1].innerHTML = hotNumberText.children[1].innerHTML
                                                })

                                            } else {
                                                post('http://175.178.4.54:3007/like/likeArticle', `article_id=${entertainmentArticle[i].articleId}`, function(data) {
                                                    console.log(data);
                                                    others_love_comment_collect.children[0].innerHTML = '&#xe642;'
                                                    likingState = 1
                                                    console.log(hotNumberText);
                                                    hotNumberText.children[1].innerHTML = parseInt(hotNumberText.children[1].innerHTML) + 1
                                                    reviewBottomUpvote.children[0].innerHTML = others_love_comment_collect.children[0].innerHTML
                                                    reviewBottomUpvote.children[1].innerHTML = hotNumberText.children[1].innerHTML
                                                })
                                            }
                                        })
                                        //仿照爱心点击做一个收藏点击事件
                                    others_love_comment_collect.children[2].addEventListener('click', function() {
                                            if (likingStateOfCollect == 1) {
                                                post('http://175.178.4.54:3007/star/cancelStarArticles', `article_id=${entertainmentArticle[i].articleId}`, function(data) {
                                                    console.log(data);
                                                    others_love_comment_collect.children[2].innerHTML = '&#xe8ba;'
                                                    likingStateOfCollect = 0
                                                })
                                            } else {
                                                post('http://175.178.4.54:3007/star/starArticles', `article_id=${entertainmentArticle[i].articleId}`, function(data) {
                                                    console.log(data);
                                                    others_love_comment_collect.children[2].innerHTML = '&#xe8c6;'
                                                    likingStateOfCollect = 1
                                                })
                                            }
                                        })
                                        //本来是复制上方的爱心点击代码，想到下面的爱心被点击与上方的爱心点击等效，于是将下一个爱心的点击事件与上方爱心点击事件连接起来
                                    reviewBottomUpvote.addEventListener('click', function() {
                                        others_love_comment_collect.children[0].click()
                                    })
                                    let othersMoreComment = document.querySelectorAll('.othersMoreComment')
                                    for (let i = 0; i < document.querySelectorAll('.commentBox').length; i++) {
                                        othersMoreComment[i].addEventListener('click', function() {
                                            othersMoreComment[i].style.display = 'none'
                                            let secondaryComments = document.querySelector('#secondaryComments')
                                            let othersInformationTitle = document.querySelector('#othersInformationTitle')
                                            let othersContentBody = document.querySelector('#othersContentBody')
                                            secondaryComments.style.display = 'block'
                                                //写二级评论
                                            let str2 = ''
                                            let layer = document.querySelector('#layer')
                                            for (let j = 0; j < JSON.parse(reviewReturn).list[i].childrenReviews.length; j++) {
                                                let p2 = new Promise((resolve, reject) => {
                                                    get('http://175.178.4.54:3007/userInfo/getUserInfo', `id=${JSON.parse(reviewReturn).list[i].childrenReviews[j].authorId}`, function(data) {
                                                        console.log(JSON.parse(data));
                                                        let userMessage = JSON.parse(data)
                                                        resolve(userMessage)
                                                    })
                                                })
                                                p2.then((userMessage) => {
                                                    for (let k = 0; k < JSON.parse(reviewReturn).list[i].childrenReviews.length; k++) {
                                                        str2 += `<div class="commentBox">
                                                            <div class="othersSecondaryCommentHeadportrait"><img src=${userMessage.data.avatar} ></div>
                                                            <div class="othersCommentNickname">${userMessage.data.username}</div>
                                                            <div class="othersCommentContent">${JSON.parse(reviewReturn).list[i].childrenReviews[j].content}</div>
                                                            <div class="othersCommentTime">${JSON.parse(reviewReturn).list[i].childrenReviews[j].time}</div>
                                                            <div class="othersCommentUpvote">
                                                            <div>&#xe653;</div>
                                                            <div>${JSON.parse(reviewReturn).list[i].childrenReviews[j].goodNum}</div>
                                                            </div></div>
                                                            
                                                            `
                                                    }
                                                    secondaryComments.innerHTML += str2
                                                    layer.style.display = 'block'
                                                    let putAway = document.querySelector('#putAway')
                                                    putAway.addEventListener('click', function() {
                                                        secondaryComments.style.display = 'none'
                                                        layer.style.display = 'none'
                                                        othersMoreComment[i].style.display = 'block'
                                                    })
                                                }, () => {})

                                            }

                                        })
                                    }
                                }, () => {})
                                //点进文章页以后，当前显示的页面消失，替换成文章页
                            details_title.style.display = 'block'
                            index.style.display = 'none'
                            footer.style.display = 'none'
                            let othersGoBack = document.querySelector('#othersGoBack')
                            othersGoBack.addEventListener('click', function() {
                                details_title.style.display = 'none'
                                index.style.display = 'block'
                                footer.style.display = 'flex'
                            })
                        })
                    }, () => {})
                })
            }
        },
        () => {}
    )
}

getEntertainmentArticle()

// // 密码模块

eye.addEventListener('click', function() {
        if (flag == 0) {
            // 眼睛睁开时，type为密码，目标是眼睛变为闭上
            password.type = 'text'
            eye.innerHTML = '&#xe66f;'
            flag = 1
        } else {
            // 眼睛睁开时
            password.type = 'password'
            eye.innerHTML = '&#xe78f;'
            flag = 0
        }
    })
    // 正则表达式匹配密码
let account = document.querySelector('#account')
let alert_account = document.querySelector('.alert-account')
let alert_password = document.querySelector('.alert-password')
account.addEventListener('blur', function() {
    let test = /^[a-z0-9]{4}$/i.test(account.value)
    if (test == false) {
        alert_account.children[0].style.display = 'none'
        alert_account.children[1].style.display = 'block'

    } else {
        alert_account.children[1].style.display = 'none'
        alert_account.children[0].style.display = 'block'
    }
})
password.addEventListener('blur', function() {
    let test = /^[0-9]{6}$/i.test(password.value)
    if (test == false) {
        alert_password.children[0].style.display = 'none'
        alert_password.children[1].style.display = 'block'

    } else {
        alert_password.children[1].style.display = 'none'
        alert_password.children[0].style.display = 'block'
    }
})
let exit = document.querySelector('.exit')
    // 以下全部都是内容部分
function getContent() {
    let search = document.querySelector('#search')
    let indexSearchPages = document.querySelector('#indexSearchPages')
    let indexSearchPages_article = document.querySelector('#indexSearchPages_article')
    let indexSearchPages_user = document.querySelector('#indexSearchPages_user')
    let indexSearchPages_tag = document.querySelector('#indexSearchPages_tag')
    let subheadings = document.querySelector('.subheadings')
    let pageNum = document.querySelectorAll('.page')
    let footer = document.querySelector('footer')
    let index_cancel = document.querySelector('#index_cancel')
        //在css给样式好麻烦，选择在js给他样式
    let indexSearchPages_title = document.querySelector('#indexSearchPages_title')
    subheadings.style.display = 'flex'

    indexSearchPages_title.children[0].className = 'checked'
    search.addEventListener('keydown', (event) => {
        //阻止按下回车的时候表单的默认提交行为
        if (event.keyCode === 13) { // keyCode 13 是回车键的键码值
            event.preventDefault();
            //此处统一一下，返回的数据全部用json.parse
            let p0 = new Promise((resolve, reject) => {
                //根据关键词搜索文章
                get('http://175.178.4.54:3007/search/getArticleByKeyWord', `keyWord=${search.value}&page=1&size=5`, function(data) {
                    console.log(JSON.parse(data));
                    resolve(JSON.parse(data))
                })
            })
            let p1 = new Promise((resolve, reject) => {
                    //根据标签搜索文章
                    get('http://175.178.4.54:3007/search/getArticleByLabel', `label=${search.value}&page=1&size=3`, function(data) {
                        console.log(JSON.parse(data));
                        resolve(JSON.parse(data))
                    })
                })
                //搜索标签
            let p2 = new Promise((resolve, reject) => {
                    get('http://175.178.4.54:3007/search/getLabel', `keyWord=${search.value}&page=1&size=1`, function(data) {
                        console.log(JSON.parse(data));
                        resolve(JSON.parse(data))
                    })
                })
                //搜人
            let p3 = new Promise((resolve, reject) => {
                get('http://175.178.4.54:3007/search/getUser', `keyWord=${search.value}&page=1&size=2`, function(data) {
                    console.log(JSON.parse(data));
                    resolve(JSON.parse(data))
                })
            })
            let pAll = Promise.all([p0, p1, p2, p3])
            pAll.then(res => {
                //等数据全部渲染完了以后再让盒子显示
                [articleByKeyword_data, articleByTag_data, searchTag_data, searchUser_data] = res
                if (articleByKeyword_data.status == 400) {
                    indexSearchPages_article.innerHTML = '找不到文章哦'
                    indexSearchPages.style.display = 'block'
                } else {
                    let str = ''
                    for (let i = 0; i < articleByKeyword_data.data.articleList.length; i++) {
                        str += `<div class="item"><img data-src=${articleByKeyword_data.data.articleList[i].img[0]}>
<div class="text"><span data-text=${articleByKeyword_data.data.articleList[i].title}></span><span class="more">&#xe600;</span></div>
<div class="tag"><div data-text=${articleByKeyword_data.data.articleList[i].label[0]}></div></div>
</div></div>`
                    }
                    indexSearchPages_article.innerHTML = str
                    indexSearchPages.style.display = 'block'
                    for (let i = 0; i < pageNum.length; i++) {
                        pageNum[i].style.display = 'none'
                    }
                    subheadings.style.display = 'none'
                    footer.style.display = 'none'
                    index_cancel.style.display = 'inline-block'
                    itemNum0 = indexSearchPages_article.children
                    itemNum0Arr = [...itemNum0]
                        // 当看见元素的时候，让他加载（观察者）
                    const callback = entries => {
                        for (let i = 0; i < entries.length; i++) {
                            if (entries[i].isIntersecting) {
                                let item = entries[i].target
                                let data_src0 = item.children[0].getAttribute('data-src')
                                item.children[0].setAttribute('src', data_src0)
                                let data_text0 = item.children[1].firstChild.getAttribute('data-text')
                                item.children[1].firstChild.innerHTML = data_text0
                                let data_text1 = item.children[2].firstElementChild.getAttribute('data-text')
                                item.children[2].firstElementChild.innerHTML = '#' + data_text1
                                observer.unobserve(item)
                                console.log('触发');
                                setTimeout(function() {
                                    let oItem = indexSearchPages_article.children
                                    let clientwidth = document.documentElement.clientWidth
                                    let itemWidth = oItem[0].offsetWidth
                                    let num = Math.floor(clientwidth / itemWidth)
                                    indexSearchPages_article.style.width = num * itemWidth + 'px'
                                    let hrr = []
                                    for (let i = 0; i < indexSearchPages_article.children.length; i++) {
                                        if (i < num) {
                                            hrr.push(indexSearchPages_article.children[i].offsetHeight)
                                            console.log(hrr);
                                        } else {
                                            let minHeight = Math.min(...hrr)
                                            let index = fInArray(minHeight, hrr)
                                            indexSearchPages_article.children[i].style.position = 'absolute'
                                            indexSearchPages_article.children[i].style.top = minHeight + 'px'
                                            indexSearchPages_article.children[i].style.left = index * itemWidth + 'px'
                                            hrr[index] += indexSearchPages_article.children[i].offsetHeight
                                        }
                                    }
                                    //这里设定的时间对瀑布流排序有着重大影响，待寻找原因
                                }, 100)
                            }
                        }
                    }
                    const observer = new IntersectionObserver(callback)
                    itemNum0Arr.forEach(item => {
                        observer.observe(item)
                    })

                    function fInArray(min, hrr) {
                        for (let i = 0; i < hrr.length; i++) {
                            if (hrr[i] == min) {
                                return i
                            }
                        }
                    }
                }
                //当在查找用户或查找标签时点击找文章

                //查找用户部分
                if (searchUser_data.status == 400) {
                    indexSearchPages_user.innerHTML = '没找到该用户哦'
                } else {
                    let str1 = ``
                    for (let i = 0; i < searchUser_data.data.userList.length; i++) {
                        str1 += `<div id="indexSearchPages_user-box">
    <div id="indexSearchPages_user_avatar"><img src="${searchUser_data.data.userList[i].avatar}"></div>
    <div id="indexSearchPages_user_right">
        <div id="indexSearchPages_user_name">${searchUser_data.data.userList[i].username}</div>
        <div id="indexSearchPages_user_id">ID:${searchUser_data.data.userList[i].authorId}</div>
    </div>
</div>`
                    }
                    console.log(str1);
                    indexSearchPages_user.innerHTML = str1
                }
                //找标签部分
                if (searchTag_data.status == 400) {
                    indexSearchPages_tag.innerHTML = `找不到该标签哦`
                } else {
                    let str2 = ``
                    for (let i = 0; i < searchTag_data.data.labelList.length; i++) {
                        str2 += `<div id="searchTag_data_box">
        <span>${searchTag_data.data.labelList[i]}</span>
    </div>`
                    }
                    indexSearchPages_tag.innerHTML = str2
                }
            }, () => {})
        }
    });
    //当每个标签被点击的时候，对应页面显示，其他页面隐藏
    indexSearchPages_title.children[0].addEventListener('click', function() {
        for (let i = 0; i < indexSearchPages_title.children.length; i++) {
            indexSearchPages_title.children[i].className = ''
        }
        indexSearchPages_title.children[0].className = 'checked'
        indexSearchPages_article.style.display = 'block'
        indexSearchPages_user.style.display = 'none'
        indexSearchPages_tag.style.display = 'none'
    })
    indexSearchPages_title.children[1].addEventListener('click', function() {
        for (let i = 0; i < indexSearchPages_title.children.length; i++) {
            indexSearchPages_title.children[i].className = ''
        }
        indexSearchPages_title.children[1].className = 'checked'
        indexSearchPages_article.style.display = 'none'
        indexSearchPages_user.style.display = 'block'
        indexSearchPages_tag.style.display = 'none'
    })
    indexSearchPages_title.children[2].addEventListener('click', function() {
        for (let i = 0; i < indexSearchPages_title.children.length; i++) {
            indexSearchPages_title.children[i].className = ''
        }
        indexSearchPages_title.children[2].className = 'checked'
        indexSearchPages_article.style.display = 'none'
        indexSearchPages_user.style.display = 'none'
        indexSearchPages_tag.style.display = 'block'
    })
    index_cancel.addEventListener('click', function() {
        let find = document.querySelector('.find')
        find.style.display = 'none'
        indexSearchPages.style.display = 'none'
        subheadings.style.display = 'flex'
        pageNum[0].style.display = 'block'
        footer.style.display = 'flex'
    })

    //轮播图部分
    window.addEventListener('load', function() {
        // 1. 获取元素 
        var focus = document.querySelector('.focus');
        var ul = focus.children[0];
        // 获得focus 的宽度
        var w = focus.offsetWidth;
        var ol = focus.children[1];
        // 2. 利用定时器自动轮播图图片
        var index = 0;
        var timer = setInterval(function() {
            index++;
            var translatex = -index * w;
            ul.style.transition = 'all .3s';
            ul.style.transform = 'translateX(' + translatex + 'px)';
        }, 2000);
        // 等着我们过渡完成之后，再去判断 监听过渡完成的事件 transitionend 
        ul.addEventListener('transitionend', function() {
            // 无缝滚动
            if (index >= 3) {
                index = 0;
                // 去掉过渡效果 这样让我们的ul 快速的跳到目标位置
                ul.style.transition = 'none';
                // 利用最新的索引号乘以宽度 去滚动图片
                var translatex = -index * w;
                ul.style.transform = 'translateX(' + translatex + 'px)';
            } else if (index < 0) {
                index = 2;
                ul.style.transition = 'none';
                // 利用最新的索引号乘以宽度 去滚动图片
                var translatex = -index * w;
                ul.style.transform = 'translateX(' + translatex + 'px)';
            }
            // 3. 小圆点跟随变化
            // 把ol里面li带有current类名的选出来去掉类名 remove
            ol.querySelector('.current').classList.remove('current');
            // 让当前索引号 的小li 加上 current   add
            ol.children[index].classList.add('current');
        });

        // 4. 手指滑动轮播图 
        // 触摸元素 touchstart： 获取手指初始坐标
        var startX = 0;
        var moveX = 0; // 后面我们会使用这个移动距离所以要定义一个全局变量
        var flag = false;
        ul.addEventListener('touchstart', function(e) {
            startX = e.targetTouches[0].pageX;
            // 手指触摸的时候就停止定时器
            clearInterval(timer);
        });
        // 移动手指 touchmove： 计算手指的滑动距离， 并且移动盒子
        ul.addEventListener('touchmove', function(e) {
            // 计算移动距离
            moveX = e.targetTouches[0].pageX - startX;
            // 移动盒子：  盒子原来的位置 + 手指移动的距离 
            var translatex = -index * w + moveX;
            // 手指拖动的时候，不需要动画效果所以要取消过渡效果
            ul.style.transition = 'none';
            ul.style.transform = 'translateX(' + translatex + 'px)';
            flag = true; // 如果用户手指移动过我们再去判断否则不做判断效果
            e.preventDefault(); // 阻止滚动屏幕的行为
        });
        // 手指离开 根据移动距离去判断是回弹还是播放上一张下一张
        ul.addEventListener('touchend', function(e) {
            if (flag) {
                // (1) 如果移动距离大于50像素我们就播放上一张或者下一张
                if (Math.abs(moveX) > 50) {
                    // 如果是右滑就是 播放上一张 moveX 是正值
                    if (moveX > 0) {
                        index--;
                    } else {
                        // 如果是左滑就是 播放下一张 moveX 是负值
                        index++;
                    }
                    var translatex = -index * w;
                    ul.style.transition = 'all .3s';
                    ul.style.transform = 'translateX(' + translatex + 'px)';
                } else {
                    // (2) 如果移动距离小于50像素我们就回弹
                    var translatex = -index * w;
                    ul.style.transition = 'all .1s';
                    ul.style.transform = 'translateX(' + translatex + 'px)';
                }
            }
            // 手指离开的时候就重新开启定时器
            clearInterval(timer);
            timer = setInterval(function() {
                index++;
                var translatex = -index * w;
                ul.style.transition = 'all .3s';
                ul.style.transform = 'translateX(' + translatex + 'px)';
            }, 2000);
        });
    })

    // 副标题的页面切换  当每个标签被点击的时候，对应页面显示，其他页面隐藏
    pages[0].style.display = 'block'
    for (let i = 0; i < subheadings.children.length - 1; i++) {
        subheadings.children[i].addEventListener('click', function() {
            for (let j = 0; j < subheadings.children.length - 1; j++) {
                subheadings.children[j].className = ''
                pages[j].style.display = 'none'
            }
            this.className = 'checked'
            pages[i].style.display = 'block'
        })
    }
    index.style.display = 'block'
    concern.style.display = 'none'
    release.style.display = 'none'
    peripheral.style.display = 'none'
    mine.style.display = 'none'
    login.style.display = 'none'
    footer.children[0].addEventListener('click', function() {
        for (let i = 0; i < footer.children.length; i++) {
            index.style.display = 'none'
            concern.style.display = 'none'
            release.style.display = 'none'
            peripheral.style.display = 'none'
            mine.style.display = 'none'
        }
        index.style.display = 'block'
    })
    footer.children[1].addEventListener('click', function() {
        for (let i = 0; i < footer.children.length; i++) {
            index.style.display = 'none'
            concern.style.display = 'none'
            release.style.display = 'none'
            peripheral.style.display = 'none'
            mine.style.display = 'none'
            login.style.display = 'none'

        }
        concern.style.display = 'block'
    })
    footer.children[2].addEventListener('click', function() {
        for (let i = 0; i < footer.children.length; i++) {
            index.style.display = 'none'
            concern.style.display = 'none'
            release.style.display = 'none'
            peripheral.style.display = 'none'
            mine.style.display = 'none'
            login.style.display = 'none'
        }
        release.style.display = 'block'
        release.children[1].display = 'none'
    })
    let toPostArticlePage = document.querySelector('#toPostArticlePage')
    toPostArticlePage.addEventListener('click', function() {
        // postArticlePage.style.display = 'block'
        toPostArticlePage.style.display = 'none'
        release.children[1].style.display = 'block'
        footer.style.display = 'none'
    })
    footer.children[3].addEventListener('click', function() {
            for (let i = 0; i < footer.children.length; i++) {
                index.style.display = 'none'
                concern.style.display = 'none'
                release.style.display = 'none'
                peripheral.style.display = 'none'
                mine.style.display = 'none'
            }
            peripheral.style.display = 'block'
        })
        //个人主页
    footer.children[4].addEventListener('click', function() {
                for (let i = 0; i < footer.children.length; i++) {
                    index.style.display = 'none'
                    concern.style.display = 'none'
                    release.style.display = 'none'
                    peripheral.style.display = 'none'
                    mine.style.display = 'none'
                    login.style.display = 'none'

                }
                mine.style.display = 'block'
                let p0 = new Promise((resolve, reject) => {
                    //要同时拿到多个异步返回数据再执行渲染页面，试一下能不能用promiseAll
                    get('http://175.178.4.54:3007/userInfo/getUserInfo', `id=${localStorage.getItem('id')}`, function(data) {
                        console.log(JSON.parse(data).data);
                        resolve(JSON.parse(data).data)
                    })
                })
                let p1 = new Promise((resolve, reject) => {
                    get('http://175.178.4.54:3007/follow/followList', `userId=${localStorage.getItem('id')}`, function(data) {
                        console.log(JSON.parse(data));
                        let followNum
                        if (JSON.parse(data).status == 200) {
                            followNum = JSON.parse(data).data.length
                        } else {
                            followNum = 0
                        }
                        resolve(followNum)
                    })
                })
                let p2 = new Promise((resolve, reject) => {
                    get('http://175.178.4.54:3007/follow/fansList', `userId=${localStorage.getItem('id')}`, function(data) {
                        console.log(JSON.parse(data));
                        let fanNum
                        if (JSON.parse(data) != 200) {
                            fanNum = JSON.parse(data).data.length
                        } else {
                            fanNum = 0
                        }
                        resolve(fanNum)
                    })
                })
                let p3 = new Promise((resolve, reject) => {
                    get('http://175.178.4.54:3007/like/getReceiveLike', `id=${localStorage.getItem('id')}`, function(data) {
                        console.log(JSON.parse(data));
                        let receiveNum
                        if (JSON.parse(data) == 200) {
                            receiveNum = JSON.parse(data).data.length
                        } else {
                            receiveNum = 0
                        }
                        resolve(receiveNum)
                    })
                })
                let p4 = new Promise((resolve, reject) => {
                    get('http://175.178.4.54:3007/article/getUserArticle', `authorId=${localStorage.getItem('id')}&page=1&size=2`, function(data) {
                        console.log(JSON.parse(data));
                        resolve(JSON.parse(data))
                    })
                })
                let p5 = new Promise((resolve, reject) => {
                    get('http://175.178.4.54:3007/like/getLikeArticles', `id=${localStorage.getItem('id')}`, function(data) {
                        console.log(JSON.parse(data));
                        resolve(JSON.parse(data))
                    })
                })
                let p6 = new Promise((resolve, reject) => {
                    get('http://175.178.4.54:3007/star/getStarArticles', `id=${localStorage.getItem('id')}`, function(data) {
                        console.log(JSON.parse(data));
                        resolve(JSON.parse(data))
                    })
                })
                let pAll = Promise.all([p0, p1, p2, p3, p4, p5, p6]);
                pAll.then(res => {
                            console.log(res);
                            //数组解构赋值
                            [individualReturnMessage, followNum, fanNum, receiveNum, individualArticleList, individualLoveList, individualCollectList] = res
                            console.log([individualReturnMessage, followNum, fanNum, receiveNum, individualArticleList])

                            let str = `<div class="backgroundImage"><img src=${individualReturnMessage.background_img == null ? `images/white.jpg` : individualReturnMessage.background_img}></div>
            <div class="myAvatar"><img src=${individualReturnMessage.avatar == null ? `images/white.jpg` : individualReturnMessage.avatar}></div>
            <div class="myNickName">${individualReturnMessage.username}</div>
            <div class="myBriefIntroduction">ID:${localStorage.getItem('id')}</div>
            <div class="myDataList">
                <div id="myFocus">
                    <div id="myFocusNum">${followNum}</div>
                    <div id="myFocusText">关注</div>
                </div>
                <div id="myFan">
                    <div id="myFanNum">${fanNum}</div>
                    <div id="myFanText">粉丝</div>
                </div>
                <div id="myUpvote">
                    <div id="myUpvoteNum">${receiveNum}</div>
                    <div id="myUpvoteText">热度</div>
                </div>
            </div>
            <div class="myArticleLoveCollect">
                <div id="myListButton">
                    <div id="myArticleButton" class='checked'>文章</div>
                    <div id="myLoveButton">喜欢</div>
                    <div id="myCollectButton">收藏</div>
                </div>
<div id='myArticleLoveCollectList'>
            <div id="myArticleList">
            </div>
            <div id="myLoveList">
            </div>
            <div id="myCollectList">
            </div>
</div>
<div #id='individualButton'>
        <button class="goto_logout">退出登录</button>
        <button id='individualFileButton'>更新个人资料</button>
        </div>`
            console.log(mine);
            mine.innerHTML = str
            console.log(individualArticleList.data.articleList);
            let str2 = ``
            let str3 = ``
            // 先给默认是自己文章的样式，再给每个按钮被点击的样式
            let myArticleLoveCollect = document.querySelector('.myArticleLoveCollect')
            let myArticleList = document.querySelector('#myArticleList')
            let myArticleButton = document.querySelector('#myArticleButton')
            let myLoveButton = document.querySelector('#myLoveButton')
            let myCollectButton = document.querySelector('#myCollectButton')
            let myArticleLoveCollectList = document.querySelector('#myArticleLoveCollectList')
            console.log(myArticleLoveCollectList)
            //默认样式
            //给我发的文章对应的盒子内添加内容
            for (let i = 0; i < individualArticleList.data.articleList.length; i++) {
                for (let j = 0; j < individualArticleList.data.articleList[i].label.length; j++) {
                    str2 += `<i id='individualArticleTagDetails'>${individualArticleList.data.articleList[i].label[j]}</i>`
                }
                str3 += `<div id="myArticleTitle"><span>${individualArticleList.data == null ? 0 : individualArticleList.data.articleList.length}篇文章</span></div>
                <div id='individualArticleContentBody'>
                        <div id='individualArticleTime'>${individualArticleList.data.articleList[i].time}</div>
                        <div id="individualArticleImg"><img src=${individualArticleList.data.articleList[i].cover}></div>
                        <div id="individualArticleContent">${individualArticleList.data.articleList[i].title}</div>
                        <div id="individualArticleTag">${str2}</div>
                        <div id="individualArticle_love_comment_collect"><span id='individualArticleLove'>&#xe653;</span><span id='individualArticleFanNum'>${individualArticleList.data.articleList[i].fanNum}</span><span id="individualArticleCommentIcon">&#xe8b4;</span><span id='individualArticlereviewNum'>${individualArticleList.data.articleList[i].reviewNum}</span></div>
                        <div id="individualArticleFanNum_commentNum">
                        </div>
                        </div>`
            }
            myArticleList.innerHTML = str3
            console.log(myArticleList);
            //除了第一个以外的'xx篇文章'隐藏，让i=1开始计数就好
            for (let i = 1; i < individualArticleList.data.articleList.length; i++) {
                let myArticleTitle = document.querySelector('#myArticleList').querySelectorAll('#myArticleTitle')
                console.log(myArticleTitle[i]);
                myArticleTitle[i].style.display = 'none'
            }
            //我的文章被点击样式
            myArticleButton.addEventListener('click', function () {


                let str2 = ``
                let str = ''
                for (let i = 0; i < individualArticleList.data.articleList.length; i++) {
                    for (let j = 0; j < individualArticleList.data.articleList[i].label.length; j++) {
                        str2 += `<i id='individualArticleTagDetails'>${individualArticleList.data.articleList[i].label[j]}</i>`
                    }
                    str += `<div id="myArticleTitle"><span>${individualArticleList.data == null ? 0 : individualArticleList.data.articleList.length}篇文章</span></div>
                    <div id='individualArticleContentBody'>
                                <div id='individualArticleTime'>${individualArticleList.data.articleList[i].time}</div>
                                <div id="individualArticleImg"><img src=${individualArticleList.data.articleList[i].cover} ></div>
                                <div id="individualArticleContent">${individualArticleList.data.articleList[i].title}</div>
                                <div id="individualArticleTag">${str2}</div>
                                <div id="individualArticle_love_comment_collect"><span id='individualArticleLove'>&#xe653;</span><span id='individualArticleFanNum'>${individualArticleList.data.articleList[i].fanNum}</span><span id="individualArticleCommentIcon">&#xe8b4;</span><span id='individualArticlereviewNum'>${individualArticleList.data.articleList[i].reviewNum}</span></div>
                                <div id="individualArticleFanNum_commentNum">
                                </div>
                                `
                }
                myArticleList.innerHTML = str
                //除了第一个意外的'xx篇文章'隐藏，让i=1开始计数就好
                for (let i = 1; i < individualArticleList.data.articleList.length; i++) {
                    let myArticleTitle = document.querySelector('#myArticleList').querySelectorAll('#myArticleTitle')
                    myArticleTitle[i].style.display = 'none'
                }

                for (let i = 0; i < 3; i++) {
                    myListButton.children[i].className = ''
                    myArticleLoveCollectList.children[i].style.display = 'none'
                }
                this.className = 'checked'
                myArticleList.style.display = 'block'

            })
            //我的喜欢被点击
            myLoveButton.addEventListener('click', function () {
                if(individualLoveList.status==400){
                    myLoveList.innerHTML = '还没有喜欢的文章哦'
                    for (let i = 0; i < 3; i++) {
                        myListButton.children[i].className = ''
                        myArticleLoveCollectList.children[i].style.display = 'none'
                    }
                    this.className = 'checked'
                    myLoveList.style.display = 'block'
                }else{
                    let str2 = ``
                    //图片要是没上传且没有alt的话就不会报错
                    let str = ''
                    console.log(individualLoveList.data);
                    for (let i = 0; i < individualLoveList.data.pages.length; i++) {
                        let imgArr = individualLoveList.data.pages[i].img.split(',')
                        console.log(imgArr);
                        str += `<div id="myLoveTitle"><span>${individualLoveList.data.pages == null ? 0 : individualLoveList.data.pages.length}篇文章</span></div>
                        <div id='individualLoveContentBody'>
                                    <div id='individualLoveTime'>${individualLoveList.data.pages[i].time}</div>
                                    <div id="individualLoveImg"><img src=${imgArr == undefined ? '' : imgArr[0]}></div>
                                    <div id="individualLoveContent">${individualLoveList.data.pages[i].title}</div>
                                    
                                    <div id="individualLoveFanNum_commentNum">
                                    </div>
                                    </div>`
    
                    }
                    myLoveList.innerHTML = str
                    //除了第一个意外的'xx篇文章'隐藏，让i=1开始计数就好
                    for (let i = 1; i < individualLoveList.data.pages.length; i++) {
                        let myLoveTitle = document.querySelector('#myLoveList').querySelectorAll('#myLoveTitle')
                        console.log(myLoveTitle);
                        myLoveTitle[i].style.display = 'none'
                    }
                    // 图片加载不出来的话隐藏
                    for (let i = 0; i < individualLoveList.data.pages.length; i++) {
                        let individualLoveImg = myLoveList.querySelectorAll('#individualLoveImg')
                        individualLoveImg[i].children[0].addEventListener('error', function () {
                            individualLoveImg[i].children[0].style.display = 'none'
                        })
                    }
                    for (let i = 0; i < 3; i++) {
                        myListButton.children[i].className = ''
                        myArticleLoveCollectList.children[i].style.display = 'none'
                    }
                    this.className = 'checked'
                    myLoveList.style.display = 'block'
                }
                
            })
            //我的收藏被点击
            myCollectButton.addEventListener('click', function () {
                let myCollectList=document.querySelector('#myCollectList')
                let str = ''
                console.log(individualCollectList);
                if (individualCollectList.status != 400) {
                    for (let i = 0; i < individualCollectList.data.pages.length; i++) {
                        let imgArr = individualCollectList.data.pages[i].img.split(',')
                        console.log(imgArr);
                        str += `<div id="myCollectTitle"><span>${individualCollectList.data == null ? 0 : individualCollectList.data.pages.length}篇文章</span></div>
                        <div id='individualCollectContentBody'>
                                <div id='individualCollectTime'>${individualCollectList.data.pages[i].time}</div>
                                <div id="individualCollectImg"><img src=${imgArr == undefined ? '' : imgArr[0]} ></div>
                              <div id="individualCollectContent">${individualCollectList.data.pages[i].title}</div>
                              <div id="individualCollectFanNum_commentNum">
                              </div>
                              </div>`
                    }
                    myCollectList.innerHTML = str
                    console.log(myCollectList);
                    //除了第一个以外的'xx篇文章'隐藏，让i=1开始计数就好
                    for (let i = 1; i < individualCollectList.data.pages.length; i++) {
                        let myCollectTitle =myCollectList.querySelectorAll('#myCollectTitle')
                        console.log(myCollectTitle);
                        myCollectTitle[i].style.display = 'none'
                    }
                    // 图片加载不出来的话隐藏
                    for (let i = 0; i < individualCollectList.data.pages.length; i++) {
                        let individualCollectImg = myCollectList.querySelectorAll('#individualCollectImg')
                        individualCollectImg[i].children[0].addEventListener('error', function () {
                            individualCollectImg[i].children[0].style.display = 'none'
                        })
                    }
                } else {
                    myCollectList.innerHTML = '暂时还没有文章,快去收藏一篇吧！'
                }
                for (let i = 0; i < 3; i++) {
                    myListButton.children[i].className = ''
                    myArticleLoveCollectList.children[i].style.display = 'none'
                }
                this.className = 'checked'
                myCollectList.style.display = 'block'
            })
            //这里要用上之前异步请求的数据，因此也把底下盒子的点击给写了    没写成
            let goto_logout = document.querySelector('.goto_logout')
            goto_logout.addEventListener('click', function () {
                get("http://175.178.4.54:3007/userInfo/logout", '', function (data) {
                    console.log(data);
                    if (JSON.parse(data).data.message == "退出登录成功！") {
                        alert('退出登录成功')
                        localStorage.removeItem('token')
                        localStorage.removeItem('id')
                        footer.style.display = 'none'
                        getLogin()
                    }
                })
            })
            //更新个人信息界面
            let individualFileButton = document.querySelector('#individualFileButton')
            individualFileButton.addEventListener('click',function () {
                mine.style.display='none'
                individualFile.style.display='block'
            })
            let p = new Promise((resolve, reject) => {
                get('http://175.178.4.54:3007/userInfo/getUserInfo', `id=${localStorage.getItem('id')}`, function (data) {
                    console.log(JSON.parse(data));
                    resolve(JSON.parse(data))
                })
            })
            p.then((individualData) => {
                let individualFileContent = ` <div id="editIndividualFile_Title">
<span id="individualFile_leave">&#xe8ef;</span><span>编辑个人资料</span>
</div>
<form action="" id="postHeadportrait">
<input type="file" id="individualHeadportrait">
<div id="individualHeadportraitCover"><img src=${individualData.data.avatar == null ? `secondRoundOperation/images/white.jpg` : individualData.data.avatar}></div>
</form>
<div id="individualFile_nickname">
<span>昵称</span>
<form action="" id="postNickname">
<input type="text" value=${individualData.data.username}>
</form>
</div>
<div id="individualFile_id">
<span>LOFTER ID</span>
<form action="" id="postId">
<input type="text"  onkeydown="return false" onkeyup="return false" oncontextmenu="return false" value=${localStorage.getItem('id')}>
</form>
</div>
<div id="individualFile_background">
<span>主页背景</span>
<form action="" id="postBackground">
    <input type="file" id="individualBackground">
<div id="individualBackgroundCover"><img src=${individualData.data.background_img == null ? `` : individualData.data.background_img}><span>+</span></div>
</form>
</div>
<div id="individualFile_gender">
<span>性别</span>
<form action="" id="postGender">
<input type="text" value=${individualData.data.gender}>
</form>
</div>
<div id="individualFile_birthday">
<span>生日</span>
<form action="" id="postBirthday">
<input type="text" value=${individualData.data.birthday == null ? `您还未输入哦` : individualData.data.birthday}>
</form>
</div>
<div id="individualFile_intro">
<span>个人简介</span>
<form action="" id="postIntro">
<input type="text" value=${individualData.data.intro == null ? `您还未输入哦` : individualData.data.intro}>
</form>
</div>
<button id="saveIndividualFile">保存</button>`
                individualFile.innerHTML = individualFileContent
                let individualHeadportraitCover = document.querySelector('#individualHeadportraitCover')
                let individualHeadportrait = document.querySelector('#individualHeadportrait')
                let postHeadportrait = document.querySelector('#postHeadportrait')
                // 头像上的盒子被点击等于提交头像按钮被点击
                individualHeadportraitCover.addEventListener('click', function () {
                    individualHeadportrait.click()
                })
                individualHeadportrait.addEventListener('change', function (event) {
                    console.log(individualHeadportrait.files);
                    individualHeadportraitCover.children[0].src = URL.createObjectURL(this.files[0])
                    // 本来什么都没有的，如果选择了图片的话就让他可被预览
                    if (document.querySelector('#individualHeadportraitCover').querySelector('img')) {
                        document.querySelector('#individualHeadportraitCover').querySelector('img').style.display = 'block'
                    }
                })
                let individualBackgroundCover = document.querySelector('#individualBackgroundCover')
                let individualBackground = document.querySelector('#individualBackground')
                // 与头像一样，当点击事件等效
                individualBackgroundCover.addEventListener('click', function () {
                    individualBackground.click()
                })
                //如果conver里面有图片的话，让图片显示  不能这样，如果这样的话下面的input:type=file是没有文件
                // individualData.data.background_img==null?individualBackgroundCover.querySelector('img').style.display='none':individualBackgroundCover.querySelector('img').style.display='block'
                individualBackground.addEventListener('change', function (event) {
                    console.log(individualBackground.files);
                    individualBackgroundCover.children[0].src = URL.createObjectURL(this.files[0])
                    // 本来什么都没有的，如果选择了图片的话就让他可被预览
                    if (document.querySelector('#individualBackgroundCover').querySelector('img')) {
                        document.querySelector('#individualBackgroundCover').querySelector('img').style.display = 'block'
                    }
                })
                let saveIndividualFile = document.querySelector('#saveIndividualFile')
                let formNum = individualFile.querySelectorAll('form')
                console.log(formNum);
                for (i = 0; i < formNum.length; i++) {
                    console.log(formNum[i]);
                    formNum[i].addEventListener('change', function (event) {
                        saveIndividualFile.style.display = 'block'
                    })
                }
                //保存按钮出现以后可以点击提交数据
                saveIndividualFile.addEventListener('click', function () {
                    //等头像，信息，背景发出去以后再来个提示：提交成功
                    //发送头像
                    //发现只需在提交个人信息处提交一个formdata即可，需补充avatar和background 乱搞，根本不是这样，我急了 
                    let p0 = new Promise((resolve, reject) => {
                        // console.log(individualHeadportraitCover.querySelector('img'));
                        let form = new FormData()
                        form.append('username', formNum[1].children[0].value)
                        form.append('gender', formNum[4].children[0].value)
                        form.append('intro', formNum[6].children[0].value)
                        form.append('birthday', formNum[5].children[0].value)
                        formData_post('http://175.178.4.54:3007/userInfo/updateUserInfo', form, function (data) {
                            console.log(data);
                            resolve(data)
                        })
                    })
                    let p1 = new Promise((resolve, reject) => {
                        let form = new FormData()
                        console.log(individualHeadportraitCover.querySelector('img'));
                        form.append('avatar', individualHeadportrait.files[0])
                        formData_post('http://175.178.4.54:3007/userInfo/uploadAvatar', form, function (data) {
                            console.log(data);
                            resolve(data)
                        })
                    })
                    let p2 = new Promise((resolve, reject) => {
                        let form = new FormData()
                        console.log(individualBackgroundCover.querySelector('img'));
                        form.append('background_img', individualBackground.files[0])
                        formData_post('http://175.178.4.54:3007/userInfo/uploadBackground', form, function (data) {
                            console.log(data);
                            resolve(data)
                        })
                    })
                })
                let individualFile_leave = document.querySelector('#individualFile_leave')
                individualFile_leave.addEventListener('click', function () {
                    individualFile.style.display = 'none'
                    mine.style.display='block'
                })
//退出登录按钮
            // 仿照首页的文章被点击 没成功，请求发不出去，待检查问题
            ////////////////////////////////////////////////////////////////
            // let individualArticleContentBody = document.querySelectorAll('#individualArticleContentBody')
            // for(let i=0;i<individualArticleContentBody.length;i++){
            //     console.log(individualArticleContentBody[i]);
            //                 //在获取文章详细信息之前，先检测一下文章有没有被我喜欢
            //                 individualArticleContentBody[i].addEventListener('click', function() {
            //                     // linkState初始值是0，如果发送取消喜欢请求后成功取消的话，那么说明已经喜欢过了，让linkState等于1，并发送一次喜欢请求恢复原样
            //                     let likingState = 0
            //                     let p = new Promise((resolve, reject) => {
            //                         //到这里的请求发不出去
            //                         post('http://175.178.4.54:3007/like/cancelLikeArticle', `article_id=${individualArticleList[i].articleId}`, function(data) {
            //                             console.log(JSON.parse(data));
            //                             if (JSON.parse(data).message != '您还没有喜欢过该文章') {
            //                                 post('http://175.178.4.54:3007/like/likeArticle', `article_id=${individualArticleList[i].articleId}`, function(data) {
            //                                     console.log(data);
            //                                 })
            //                                 likingState = 1
            //                             } else {
            //                                 likingState = 0
            //                             }
            //                             resolve(likingState)
            //                         })
            //                     })
            //                     p.then((likingState) => {
            //                         get('http://175.178.4.54:3007/article/getDetails', `articleId=${individualArticleList[i].articleId}`, function(data) {
            //                             console.log(JSON.parse(data));
            //                             let details_title = document.querySelector('#details_title')
            //                             console.log(details_title);
            //                             //将除了底下的评论部分的内容放进页面中
            //                             let str = `
            //             <div id="othersInformation">
            //             <div id='othersInformationTitle'>
            //             <div id="othersGoBack">&#xe8ef;</div>
            //             <div id="othersHeadPortrait"><img src=${JSON.parse(data).data.avatar} alt=""></div>
            //             <div id="othersName_time">
            //                 <div id="othersName">${JSON.parse(data).data.authorName}</div>
            //                 <div id="othersTime">${JSON.parse(data).data.time}</div>
            //             </div>
            //             <div id="othersFocus">关注</div>
            //             </div>
            //             <div id='othersContentBody'>
            //             <div id="othersImg"><img src=${JSON.parse(data).data.img[0]} alt=""></div>
            //             <div id="othersContent">${JSON.parse(data).data.content}</div>
            //             <div id="othersTag"></div>
            //             <div id="others_love_comment_collect"><span>&#xe653;</span><span id="commentIcon">&#xe8b4;</span><span id="collectIcon">&#xe8ba;</span></div>
            //             <div id="fanNum_commentNum">
            //                 <i id="hotNumberText"><span>热度</span> <span>${JSON.parse(data).data.fanNum}</span></i>
            //                 <i id="commentNumberText"><span>评论</span> <span>${JSON.parse(data).data.reviewNum}</span></i>
            //             </div>
            //             </div>
            //             <div id="comment">
            //             <div id="hotComment">热门评论</div>
            //             <div id="commentDetails"></div>
            //             <div id="reviewBottom"><input type="text" placeholder="我要发评论">
            //             <div id='reviewBottomUpvote'>
            //             <div>&#xe653;</div>
            //             <div>${JSON.parse(data).data.fanNum}</div>
            //             </div>
            //             <div id='reviewBottomReview'>
            //             <div>&#xe8b4;</div>
            //             <div>${JSON.parse(data).data.reviewNum}</div>
            //             </div>
            //             </div>
            //             <div id='secondaryComments'><span id='putAway'>&#xe601;</span></div>
            //             <div id="checkMoreReview">查看更多评论</div>
            //             </div>
            //             </div>`
            //                             details_title.innerHTML = str
            //                                 //文章中的各种数据
            //                             let hotNumberText = document.querySelector('#hotNumberText')
            //                             let img = document.querySelector('#othersImg').children[0]
            //                             img.addEventListener('error', function() {
            //                                 this.style.display = 'none'
            //                             })
            //                             let othersTag = document.querySelector('#othersTag')
            //                                 // console.log(othersTag);
            //                             for (let i = 0; i < JSON.parse(data).data.label.length; i++) {
            //                                 othersTag.innerHTML += `<i>${JSON.parse(data).data.label[i]}</i>`
            //                             }
            //                             let others_love_comment_collect = document.querySelector('#others_love_comment_collect')
            //                             if (likingState == 1) {
            //                                 others_love_comment_collect.children[0].innerHTML = '&#xe642;'
            //                             } else {
            //                                 others_love_comment_collect.children[0].innerHTML = '&#xe653;'
            //                             }

            //                             // 加载具体的评论
            //                             let p6 = new Promise((resolve, reject) => {
            //                                 get('http://175.178.4.54:3007/review/getReviewsByArt', `articleId=${individualArticleList[i].articleId}&page=1&size=2`, function(data) {
            //                                     let reviewReturn = data
            //                                     console.log(JSON.parse(reviewReturn));
            //                                     resolve(reviewReturn)
            //                                 })
            //                             })
            //                             p6.then((reviewReturn) => {
            //                                     // 在热门评论处添加评论
            //                                     let str1 = ''
            //                                     let commentDetails = document.querySelector('#commentDetails')
            //                                     for (let i = 0; i < JSON.parse(reviewReturn).list.length; i++) {
            //                                         str1 += `<div class="commentBox">
            //             <div class="othersCommentHeadportrait"><img src=${JSON.parse(reviewReturn).list[i].userInfo.avatar} alt=""></div>
            //             <div class="othersCommentNickname">${JSON.parse(reviewReturn).list[i].userInfo.userName}</div>
            //             <div class="othersCommentContent">${JSON.parse(reviewReturn).list[i].content}</div>
            //             <div class="othersCommentTime">${JSON.parse(reviewReturn).list[i].time}</div>
            //             <div class="othersMoreComment">-查看更多<span>${JSON.parse(reviewReturn).list[i].childrenReviews.length}</span>条回复-</div>
            //             <div class="othersCommentUpvote">
            //             <div>&#xe653;</div>
            //             <div>${JSON.parse(reviewReturn).list[i].goodNum}</div>
            //             </div>
            //             </div>
            //             </div><div id='layer'></div>`
            //                                     }

            //                                     //此处移植过去后可先判断没有评论的情况，顺便把展开更多评论也改一下
            //                                     commentDetails.innerHTML = str1
            //                                         //如果评论数小于等于2，则隐藏展示更多评论的功能
            //                                     let checkMoreReview = document.querySelector('#checkMoreReview')
            //                                     if (JSON.parse(reviewReturn).list.length <= 2) {
            //                                         checkMoreReview.style.display = 'none'
            //                                     }
            //                                     //如果评论的子评论数=0，则隐藏展示子评论的功能
            //                                     for (let i = 0; i < JSON.parse(reviewReturn).list.length; i++) {
            //                                         if (JSON.parse(reviewReturn).list[i].childrenReviews.length == 0) {
            //                                             let othersMoreComment = document.querySelectorAll('.othersMoreComment')
            //                                             othersMoreComment[i].style.display = 'none'
            //                                         }
            //                                     }

            //                                     // 让发评论旁边的小爱心即点赞数与上方的一致
            //                                     let reviewBottomUpvote = document.querySelector('#reviewBottomUpvote')
            //                                     console.log();
            //                                     reviewBottomUpvote.children[0].innerHTML = others_love_comment_collect.children[0].innerHTML
            //                                     reviewBottomUpvote.children[1].innerHTML = hotNumberText.children[1].innerHTML
            //                                         // 当上方的爱心被点击时
            //                                     others_love_comment_collect.children[0].addEventListener('click', function() {
            //                                             if (likingState == 1) {
            //                                                 post('http://175.178.4.54:3007/like/cancelLikeArticle', `article_id=${individualArticleList[i].articleId}`, function(data) {
            //                                                     console.log(data);
            //                                                     others_love_comment_collect.children[0].innerHTML = '&#xe653;'
            //                                                     likingState = 0
            //                                                     let hotNumberText = document.querySelector('#hotNumberText')
            //                                                     hotNumberText.children[1].innerHTML = parseInt(hotNumberText.children[1].innerHTML) - 1
            //                                                     reviewBottomUpvote.children[0].innerHTML = others_love_comment_collect.children[0].innerHTML
            //                                                     reviewBottomUpvote.children[1].innerHTML = hotNumberText.children[1].innerHTML
            //                                                 })

            //                                             } else {
            //                                                 post('http://175.178.4.54:3007/like/likeArticle', `article_id=${individualArticleList[i].articleId}`, function(data) {
            //                                                     console.log(data);
            //                                                     others_love_comment_collect.children[0].innerHTML = '&#xe642;'
            //                                                     likingState = 1

            //                                                     console.log(hotNumberText);
            //                                                     hotNumberText.children[1].innerHTML = parseInt(hotNumberText.children[1].innerHTML) + 1
            //                                                     reviewBottomUpvote.children[0].innerHTML = others_love_comment_collect.children[0].innerHTML
            //                                                     reviewBottomUpvote.children[1].innerHTML = hotNumberText.children[1].innerHTML
            //                                                 })
            //                                             }
            //                                         })
            //                                         //本来是复制上方的爱心点击代码，想到下面的爱心被点击与上方的爱心点击等效，于是将下一个爱心的点击事件与上方爱心点击事件连接起来
            //                                     reviewBottomUpvote.addEventListener('click', function() {
            //                                         others_love_comment_collect.children[0].click()
            //                                     })
            //                                     let othersMoreComment = document.querySelectorAll('.othersMoreComment')
            //                                     for (let i = 0; i < document.querySelectorAll('.commentBox').length; i++) {
            //                                         othersMoreComment[i].addEventListener('click', function() {
            //                                             othersMoreComment[i].style.display = 'none'
            //                                             let secondaryComments = document.querySelector('#secondaryComments')
            //                                             let othersInformationTitle = document.querySelector('#othersInformationTitle')
            //                                             let othersContentBody = document.querySelector('#othersContentBody')
            //                                             secondaryComments.style.display = 'block'
            //                                                 // othersInformationTitle.style.display = 'none'
            //                                                 // othersContentBody.style.display = 'none'
            //                                                 // hotComment.style.display = 'none'
            //                                                 // commentDetails.style.display = 'none'
            //                                                 // reviewBottom.style.display = 'none'
            //                                                 //写二级评论
            //                                             let str2 = ''
            //                                             let layer = document.querySelector('#layer')
            //                                             for (let j = 0; j < JSON.parse(reviewReturn).list[i].childrenReviews.length; j++) {
            //                                                 let p7 = new Promise((resolve, reject) => {
            //                                                     get('http://175.178.4.54:3007/userInfo/getUserInfo', `id=${JSON.parse(reviewReturn).list[i].childrenReviews[j].authorId}`, function(data) {
            //                                                         console.log(JSON.parse(data));
            //                                                         let userMessage = JSON.parse(data)
            //                                                         resolve(userMessage)
            //                                                     })
            //                                                 })
            //                                                 p7.then((userMessage) => {
            //                                                     for (let k = 0; k < JSON.parse(reviewReturn).list[i].childrenReviews.length; k++) {
            //                                                         str2 += `<div class="commentBox">
            //                                                         <div class="othersSecondaryCommentHeadportrait"><img src=${userMessage.data.avatar} alt=""></div>
            //                                                         <div class="othersCommentNickname">${userMessage.data.username}</div>
            //                                                         <div class="othersCommentContent">${JSON.parse(reviewReturn).list[i].childrenReviews[j].content}</div>
            //                                                         <div class="othersCommentTime">${JSON.parse(reviewReturn).list[i].childrenReviews[j].time}</div>
            //                                                         <div class="othersCommentUpvote">
            //                                                         <div>&#xe653;</div>
            //                                                         <div>${JSON.parse(reviewReturn).list[i].childrenReviews[j].goodNum}</div>
            //                                                         </div></div>

            //                                                         `
            //                                                     }
            //                                                     secondaryComments.innerHTML += str2
            //                                                     layer.style.display = 'block'
            //                                                     let putAway = document.querySelector('#putAway')
            //                                                     putAway.addEventListener('click', function() {
            //                                                         secondaryComments.style.display = 'none'
            //                                                         layer.style.display = 'none'
            //                                                         othersMoreComment[i].style.display = 'block'
            //                                                     })
            //                                                 }, () => {})

            //                                             }

            //                                         })
            //                                     }
            //                                 }, () => {})
            //                                 //点进文章页以后，当前显示的页面消失，替换成文章页
            //                             details_title.style.display = 'block'
            //                             mine.style.display = 'none'
            //                             footer.style.display = 'none'
            //                             let othersGoBack = document.querySelector('#othersGoBack')
            //                             othersGoBack.addEventListener('click', function() {
            //                                 details_title.style.display = 'none'
            //                                 mine.style.display = 'block'
            //                                 footer.style.display = 'flex'
            //                                     // let othersMoreComment = document.querySelectorAll('.othersMoreComment')
            //                                     // for (let i = 0; i < othersMoreComment.length; i++) {
            //                                     //     othersMoreComment[i].style.display = 'block'

            //                                 // }
            //                             })
            //                         })
            //                     }, () => {})
            //                 })
            // }
            }, () => { })
        })
    })
    //发布文章的退出按钮
    let leave = document.querySelector('#leave')
    leave.addEventListener('click', function () {
        tagBox.style.display = 'none'
        published.style.display = 'none'
        toPostArticlePage.style.display = 'block'
        footer.style.display = 'flex'
    })

    let addTagPage = document.querySelector('#addTagPage')
    let tagBox = document.querySelector('#tagBox')

    //点击了按钮以后才能发表文章
    let published = document.querySelector('#published')
    toPostArticlePage.addEventListener('click', function () {
        toPostArticlePage.style.display = 'none'
        published.style.display = 'block'
        tagBox.style.display = 'block'
    })
    //让覆盖的盒子被点击等于原有的上传文件按钮被点击
    let fileCover = document.querySelector('#fileCover')
    let postFile = document.querySelector('#postFile')
    let postTitle = document.querySelector('#postTitle')
    let postArticle = document.querySelector('#postArticle')
    fileCover.addEventListener('click', function () {
        postFile.click()
    })

    //当没有图片时，隐藏原有占位的图片
    if (document.querySelector('#fileCover').querySelector('img').src != true) {
        document.querySelector('#fileCover').querySelector('img').style.display = 'none'
    }


    //当图片有了以后，再让图片出现
    postFile.addEventListener('change', function (event) {
        console.log(postFile.files);
        fileCover.children[0].src = URL.createObjectURL(this.files[0])
        if (document.querySelector('#fileCover').querySelector('img')) {
            document.querySelector('#fileCover').querySelector('img').style.display = 'block'
        }
    })

    // 添加标签页面
    let postArticleTagButton = document.querySelector('#postArticleTagButton')
    postArticleTagButton.addEventListener('click', function () {
        // post.style.display = 'none'
        toPostArticlePage.style.display = 'none'
        published.style.display = 'none'
        tagBox.style.display = 'none'
        addTagPage.style.display = 'block'
    })

    let addTagPage_finish = document.querySelector('#addTagPage_finish')
    let inputTag = document.querySelector('#inputTag')
    addTagPage_finish.addEventListener('click', function () {
        if (inputTag.value) {
            addTag.innerHTML += '#' + inputTag.value
            inputTag.value == ''
        }
        addTagPage.style.display = 'none'
        published.style.display = 'block'
        tagBox.style.display = 'block'
    })

    let postArticleButton = document.querySelector('#postArticlePage')
    postArticleButton.addEventListener('click', function () {
        console.log(postFile.files);
    })
    let postArticlePage = document.querySelector('#postArticlePage')
    postArticlePage.addEventListener('click', function () {
        let form = new FormData()
        let addTag = document.querySelector('#addTag')
        console.log(postFile.files[0]);
        form.append('img', postFile.files[0])
        form.append('title', postTitle.value)
        form.append('content', postArticle.value)
        form.append('label', [addTag.innerText])
        formData_post("http://175.178.4.54:3007/article/publish", form, function (data) {
            console.log(data);
            if (JSON.parse(data).status == 200) {
                alert('发布成功')
                leave.click()
            } else {
                alert('未成功发布,请检查后重试')
            }
        })
    })
}

if (localStorage.getItem('token') == null) {
    getLogin()
} else {
    getIndex()
    getContent()
}